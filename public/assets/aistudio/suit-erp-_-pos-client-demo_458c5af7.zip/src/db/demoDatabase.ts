/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import {
  AuditLog,
  Customer,
  FamilyMember,
  BespokeMeasurements,
  MeasurementRevision,
  AlterationRecord,
  ExpenseEntry,
  Order,
  OrderStatus,
  PaymentEntry,
  Product,
  SystemNotification,
  ThermalPrinterConfig,
  UserAccount,
  UserRole,
  WhatsAppCloudApiConfig,
  WhatsAppConversation
} from '../types/index.ts';

// User Account Definitions with Passwords & Granular Permissions
export const ADMIN_USER: UserAccount = {
  id: 'usr_admin_01',
  username: 'admin',
  password: 'admin123',
  name: 'Administrator',
  email: 'admin@atelier.com',
  role: 'ADMIN',
  title: 'Managing Director & Master Tailor',
  createdAt: '2026-01-01',
  permissions: {
    canViewProfits: true,
    canViewCustomerPhone: true,
    canViewCustomerAddress: true,
    canViewPrivateWhatsApp: true,
    canManageSettings: true,
    canDeleteRecords: true,
    canExportData: true,
    canViewFinancialTotals: true,
    canEditMeasurements: true,
    canApplyDiscounts: true,
    allowedViews: ['dashboard', 'orders', 'products', 'customers', 'thermal', 'finance', 'settings', 'audit'],
  },
};

export const EMPLOYEE_USER: UserAccount = {
  id: 'usr_emp_02',
  username: 'sales',
  password: 'sales123',
  name: 'Hamza Farooq',
  email: 'sales@sartoriallibas.pk',
  role: 'EMPLOYEE',
  title: 'Showroom Sales & Fitting Associate',
  createdAt: '2026-01-15',
  permissions: {
    canViewProfits: false,
    canViewCustomerPhone: false, // Salesperson can only see name, NOT phone number
    canViewCustomerAddress: false, // Salesperson only sees city, address hidden
    canViewPrivateWhatsApp: false,
    canManageSettings: false,
    canDeleteRecords: false,
    canExportData: false,
    canViewFinancialTotals: false, // Total revenue and cashflow balances hidden
    canEditMeasurements: true,
    canApplyDiscounts: true,
    allowedViews: ['orders', 'products', 'customers', 'thermal'],
  },
};

export const INITIAL_USERS: UserAccount[] = [ADMIN_USER, EMPLOYEE_USER];

const STORAGE_KEYS = {
  PRODUCTS: 'zs_bespoke_products_v2',
  ORDERS: 'zs_bespoke_orders_v2',
  CUSTOMERS: 'zs_bespoke_customers_v2',
  PAYMENTS: 'zs_bespoke_payments_v2',
  EXPENSES: 'zs_bespoke_expenses_v2',
  WHATSAPP: 'zs_bespoke_whatsapp_v2',
  AUDIT_LOGS: 'zs_bespoke_audit_logs_v2',
  NOTIFICATIONS: 'zs_bespoke_notifications_v2',
  PRINTER_CONFIG: 'zs_bespoke_printer_v2',
  WHATSAPP_CONFIG: 'zs_bespoke_whatsapp_cfg_v2',
  CURRENT_USER: 'zs_bespoke_current_user_v2',
  USERS: 'zs_bespoke_users_v2',
  AUTH_SESSION: 'zs_bespoke_auth_session_v2',
  CATEGORIES: 'zs_bespoke_categories_v2',
  CITIES: 'zs_bespoke_cities_v2',
  THEME: 'zs_bespoke_theme_v2',
};

// Automatic cleanup of legacy demo records from v1
try {
  if (typeof window !== 'undefined' && window.localStorage) {
    const v1Keys = [
      'zs_bespoke_products_v1',
      'zs_bespoke_orders_v1',
      'zs_bespoke_customers_v1',
      'zs_bespoke_payments_v1',
      'zs_bespoke_expenses_v1',
      'zs_bespoke_whatsapp_v1',
      'zs_bespoke_audit_logs_v1',
      'zs_bespoke_notifications_v1',
      'zs_bespoke_printer_v1',
      'zs_bespoke_whatsapp_cfg_v1',
      'zs_bespoke_current_user_v1',
      'zs_bespoke_categories_v1',
      'zs_bespoke_theme_v1',
    ];
    v1Keys.forEach((k) => localStorage.removeItem(k));
  }
} catch {
  // Ignore in SSR
}

const DEFAULT_CATEGORIES: string[] = [
  'Three-Piece Suit',
  'Two-Piece Italian Suit',
  'Tuxedo',
  'Prince Coat',
  'Sherwani',
  'Waistcoat',
  'Luxury Kurta Pajama',
  'Safari Suit',
  'Bespoke Blazer',
];

export const DEFAULT_CITIES: string[] = [
  'Lahore',
  'Karachi',
  'Islamabad',
  'Rawalpindi',
  'Faisalabad',
  'Peshawar',
  'Multan',
  'Sialkot',
  'Gujranwala',
  'Quetta',
  'Abbottabad',
  'Bahawalpur',
  'Sargodha',
  'Sukkur',
  'Mirpur (AJK)',
  'Overseas (UK / UAE / USA)'
];

// Clean initial empty state for live store operations (all demo data removed)
const INITIAL_PRODUCTS: Product[] = [];

// Sample Products (Available if user explicitly clicks "Load Sample Demo Data" in Settings)
export const SAMPLE_PRODUCTS: Product[] = [
  {
    id: 'prod_1',
    code: 'ZS-701',
    title: 'Super 150s Royal Navy 3-Piece Bespoke Suit',
    category: 'Three-Piece Suit',
    fabric: 'Super 150s Merino Wool (Dormeuil England)',
    color: 'Royal Navy Blue',
    pricePKR: 85000,
    costPKR: 44000,
    stockQty: 8,
    minStockAlert: 3,
    sizesAvailable: ['38R', '40R', '42R', '44L', 'Bespoke Custom'],
    imageUrl: '/src/assets/images/suit_royal_navy_3piece_1792162981461.jpg',
    description: 'Hand-canvassed Italian cut 3-piece suit with tailored waistcoat, peak lapel, horn buttons and Bemberg silk lining.',
  },
  {
    id: 'prod_2',
    code: 'ZS-702',
    title: 'Sartorial Charcoal Tuxedo with Satin Peak Lapel',
    category: 'Tuxedo',
    fabric: 'Fine Worsted Wool & Grosgrain Satin',
    color: 'Midnight Charcoal Black',
    pricePKR: 98000,
    costPKR: 51000,
    stockQty: 5,
    minStockAlert: 2,
    sizesAvailable: ['38R', '40R', '42R', 'Bespoke Custom'],
    imageUrl: '/src/assets/images/suit_charcoal_tuxedo_1792162980954.jpg',
    description: 'Black-tie luxury tuxedo. Satin facings on lapel and jetted pockets, single silk covered button, satin side stripe trouser.',
  },
  {
    id: 'prod_3',
    code: 'ZS-703',
    title: 'Imperial Emerald Velvet Prince Coat with Zardozi',
    category: 'Prince Coat',
    fabric: 'Micro Velvet with Hand Zardozi & Antique Tilla Work',
    color: 'Deep Emerald Green',
    pricePKR: 115000,
    costPKR: 58000,
    stockQty: 3,
    minStockAlert: 2,
    sizesAvailable: ['38R', '40R', '42L', 'Bespoke Custom'],
    imageUrl: '/src/assets/images/suit_emerald_princecoat_1792162982456.jpg',
    description: 'Regal South Asian wedding Prince Coat. Antique floral dabka handwork on Mandarin collar, chest crest and ornate handcrafted brass buttons.',
  },
  {
    id: 'prod_4',
    code: 'ZS-704',
    title: 'Scottish Mocha Herringbone Wool Tweed Suit',
    category: 'Two-Piece Italian Suit',
    fabric: 'Mocha Herringbone Shetland Wool (380gsm)',
    color: 'Mocha Tweed',
    pricePKR: 72000,
    costPKR: 36000,
    stockQty: 12,
    minStockAlert: 4,
    sizesAvailable: ['38R', '40R', '42R', '44R', 'Bespoke Custom'],
    imageUrl: '/src/assets/images/suit_mocha_tweed_1792162982384.jpg',
    description: 'Autumn/Winter double-vented textured jacket with ticket pocket, suede elbow patches option and pleated trousers.',
  },
  {
    id: 'prod_5',
    code: 'ZS-705',
    title: 'Vanquish Jet Black 2-Piece Corporate Power Suit',
    category: 'Two-Piece Italian Suit',
    fabric: 'Italian Tropical Poly-Wool Blend (Wrinkle Resistant)',
    color: 'Jet Black',
    pricePKR: 58000,
    costPKR: 29000,
    stockQty: 2, // Low stock on purpose
    minStockAlert: 3,
    sizesAvailable: ['38R', '40R', '42R', '44R'],
    imageUrl: '/src/assets/images/suit_charcoal_tuxedo_1792162980954.jpg',
    description: 'Everyday executive suit with notch lapel, dual slant pockets, breathable inner lining suitable for Pakistani summer.',
  },
  {
    id: 'prod_6',
    code: 'ZS-706',
    title: 'Ivory Raw Silk Sherwani with Jamawar Inner Kurta',
    category: 'Sherwani',
    fabric: 'Pure Raw Silk with Subtle Gold Thread Weave',
    color: 'Ivory Cream',
    pricePKR: 135000,
    costPKR: 69000,
    stockQty: 4,
    minStockAlert: 2,
    sizesAvailable: ['Bespoke Custom'],
    imageUrl: '/src/assets/images/suit_emerald_princecoat_1792162982456.jpg',
    description: 'Groom couture wedding sherwani with tailored churidar, matching embroidered stole and hand-carved mother of pearl buttons.',
  },
  {
    id: 'prod_7',
    code: 'ZS-707',
    title: 'Sapphire Blue Double-Breasted Waistcoat',
    category: 'Waistcoat',
    fabric: 'Italian Jacquard Silk Blend',
    color: 'Sapphire Blue',
    pricePKR: 26000,
    costPKR: 11500,
    stockQty: 15,
    minStockAlert: 5,
    sizesAvailable: ['36', '38', '40', '42', '44'],
    imageUrl: '/src/assets/images/suit_royal_navy_3piece_1792162981461.jpg',
    description: 'Classic 6-button double breasted formal waistcoat with shawl lapel and adjustable back silk cinch belt.',
  },
];

// Clean initial customer directory (all demo records removed)
const INITIAL_CUSTOMERS: Customer[] = [];

// Sample Customers (available if user explicitly clicks "Load Sample Demo Data" in Settings)
export const SAMPLE_CUSTOMERS: Customer[] = [
  {
    id: 'cust_1',
    name: 'Tariq Mehmood Bajwa',
    phone: '+92 300 8472910',
    email: 'tariq.bajwa@textilegroup.pk',
    city: 'Lahore',
    address: 'House 42, Block L, Gulberg III, Lahore',
    measurements: {
      chest: 42.5,
      waist: 36.0,
      hip: 41.0,
      shoulder: 18.5,
      sleeve: 25.5,
      jacketLength: 30.0,
      collar: 16.5,
      trouserWaist: 36.0,
      trouserLength: 41.5,
      inseam: 31.0,
      thigh: 24.5,
      lapelStyle: 'Peak Lapel',
      ventStyle: 'Double Vent',
      customNotes: 'Slightly sloping right shoulder pad (+0.25 inch padding needed). Prefers 1.75 inch trouser turn-up cuff.',
    },
    notes: 'Managing Director at Nishat Mills. Regular client for winter woolen three-piece suits.',
    totalOrdersCount: 4,
    totalSpentPKR: 340000,
    createdAt: '2025-11-10T10:30:00Z',
    familyMembers: [
      {
        id: 'fm_1_1',
        customerId: 'cust_1',
        name: 'Tariq Mehmood Bajwa',
        relationship: 'Self',
        phone: '+92 300 8472910',
        notes: 'Head of Family. Prefers English bespoke worsted wool.',
        preferences: 'Super 150s Merino Wool, Double Breasted waistcoat, horn buttons.',
        currentMeasurements: {
          chest: 42.5,
          waist: 36.0,
          hip: 41.0,
          shoulder: 18.5,
          sleeve: 25.5,
          jacketLength: 30.0,
          collar: 16.5,
          trouserWaist: 36.0,
          trouserLength: 41.5,
          inseam: 31.0,
          thigh: 24.5,
          lapelStyle: 'Peak Lapel',
          ventStyle: 'Double Vent',
          customNotes: 'Sloping right shoulder +0.25 inch. Turn-up cuff 1.75 inch.',
        },
        customFields: {
          'Armhole Depth': 9.25,
          'Cross Back': 18.0,
          'Waistcoat Length': 24.5,
        },
        measurementHistory: [
          {
            id: 'rev_1_1_1',
            date: '2026-09-12',
            measurements: {
              chest: 43.0,
              waist: 36.5,
              hip: 41.5,
              shoulder: 18.5,
              sleeve: 25.5,
              jacketLength: 30.0,
              collar: 16.5,
              trouserWaist: 36.5,
              trouserLength: 41.5,
              inseam: 31.0,
              thigh: 25.0,
              lapelStyle: 'Peak Lapel',
              ventStyle: 'Double Vent',
            },
            fitNotes: 'Pre-winter master cut. Room for heavier flannel.',
            recordedBy: 'Mian Zubair (Master Tailor)',
          },
          {
            id: 'rev_1_1_2',
            date: '2026-03-05',
            measurements: {
              chest: 42.5,
              waist: 36.0,
              hip: 41.0,
              shoulder: 18.5,
              sleeve: 25.5,
              jacketLength: 30.0,
              collar: 16.5,
              trouserWaist: 36.0,
              trouserLength: 41.5,
              inseam: 31.0,
              thigh: 24.5,
              lapelStyle: 'Peak Lapel',
              ventStyle: 'Double Vent',
            },
            fitNotes: 'Spring adjustment. Waist trimmed down by 0.5 inches.',
            recordedBy: 'Master Aslam',
          },
        ],
        alterations: [
          {
            id: 'alt_1_1',
            orderNumber: 'ZS-2026-1042',
            date: '2026-10-14',
            garment: 'Royal Navy 3-Piece Trouser',
            alterationDetails: 'Take in trouser waist by 0.5 inches and press creases.',
            status: 'Completed',
            masterTailor: 'Master Rasheed',
            costPKR: 0,
          },
        ],
        createdAt: '2025-11-10T10:30:00Z',
        updatedAt: '2026-10-14T15:40:00Z',
      },
      {
        id: 'fm_1_2',
        customerId: 'cust_1',
        name: 'Hamza Tariq Bajwa',
        relationship: 'Son',
        phone: '+92 301 5567890',
        notes: 'Groom for upcoming November wedding festivities.',
        preferences: 'Slim fit Italian cut, velvet Prince Coat, midnight black tuxedo.',
        currentMeasurements: {
          chest: 38.5,
          waist: 31.0,
          hip: 37.5,
          shoulder: 17.5,
          sleeve: 25.0,
          jacketLength: 29.0,
          collar: 15.5,
          trouserWaist: 31.5,
          trouserLength: 40.0,
          inseam: 30.5,
          thigh: 22.5,
          lapelStyle: 'Shawl Collar',
          ventStyle: 'Double Vent',
          customNotes: 'Athletic taper. High armhole.',
        },
        customFields: {
          'Sherwani / Prince Coat Length': 38.0,
          'Kamiz Daman Width': 22.0,
          'Pagri / Turban Head Size': 22.25,
          'Wrist Opening': 6.25,
        },
        measurementHistory: [
          {
            id: 'rev_1_2_1',
            date: '2026-08-20',
            measurements: {
              chest: 38.5,
              waist: 31.0,
              hip: 37.5,
              shoulder: 17.5,
              sleeve: 25.0,
              jacketLength: 29.0,
              collar: 15.5,
              trouserWaist: 31.5,
              trouserLength: 40.0,
              inseam: 30.5,
              thigh: 22.5,
              lapelStyle: 'Shawl Collar',
              ventStyle: 'Double Vent',
            },
            fitNotes: 'First bridal fitting for wedding prince coat and tuxedo.',
            recordedBy: 'Mian Zubair (Master Tailor)',
          },
        ],
        alterations: [
          {
            id: 'alt_1_2',
            orderNumber: 'ZS-2026-1046',
            date: '2026-10-15',
            garment: 'Emerald Velvet Prince Coat',
            alterationDetails: 'Collar zardozi alignment adjustment and chest darts intake 0.25 inch.',
            status: 'Ready for Fitting',
            masterTailor: 'Master Aslam',
            costPKR: 0,
          },
        ],
        createdAt: '2026-02-14T11:00:00Z',
        updatedAt: '2026-10-15T12:00:00Z',
      },
      {
        id: 'fm_1_3',
        customerId: 'cust_1',
        name: 'Asim Mehmood Bajwa',
        relationship: 'Brother',
        phone: '+92 300 9876543',
        notes: 'Partner in textile mills. Requires boardroom business suits.',
        preferences: 'Charcoal pinstripe, British structured shoulder, single vent.',
        currentMeasurements: {
          chest: 41.0,
          waist: 35.0,
          hip: 40.0,
          shoulder: 18.0,
          sleeve: 25.0,
          jacketLength: 29.5,
          collar: 16.0,
          trouserWaist: 35.0,
          trouserLength: 41.0,
          inseam: 31.0,
          thigh: 24.0,
          lapelStyle: 'Notch Lapel',
          ventStyle: 'Single Vent',
          customNotes: 'Traditional British cut with roped sleeve heads.',
        },
        customFields: {
          'Armhole Depth': 9.0,
          'Cross Back': 17.75,
        },
        measurementHistory: [],
        alterations: [],
        createdAt: '2026-01-20T14:00:00Z',
        updatedAt: '2026-01-20T14:00:00Z',
      },
      {
        id: 'fm_1_4',
        customerId: 'cust_1',
        name: 'Haji Rehmatullah Bajwa',
        relationship: 'Uncle',
        phone: '+92 321 8877665',
        notes: 'Senior family elder. Traditional bespoke Sherwanis and Boski Silk suits.',
        preferences: 'Pure Boski silk kurtas, Jamawar luxury waistcoats, relaxed comfort cut.',
        currentMeasurements: {
          chest: 44.0,
          waist: 40.0,
          hip: 43.0,
          shoulder: 18.5,
          sleeve: 24.5,
          jacketLength: 31.0,
          collar: 17.0,
          trouserWaist: 40.0,
          trouserLength: 40.5,
          inseam: 29.5,
          thigh: 26.0,
          lapelStyle: 'Mandarin Collar',
          ventStyle: 'No Vent',
          customNotes: 'Extra comfort around stomach and high rise trouser waist.',
        },
        customFields: {
          'Kamiz Daman Width': 25.0,
          'Sherwani Length': 44.0,
        },
        measurementHistory: [],
        alterations: [],
        createdAt: '2026-03-01T09:00:00Z',
        updatedAt: '2026-03-01T09:00:00Z',
      },
    ],
  },
  {
    id: 'cust_3',
    name: 'Bilal Chaudhry',
    phone: '+92 333 5192837',
    email: 'bilal@chaudhryholdings.com',
    city: 'Islamabad',
    address: 'Street 14, Sector F-7/2, Islamabad',
    measurements: {
      chest: 44.0,
      waist: 38.0,
      hip: 43.0,
      shoulder: 19.0,
      sleeve: 26.0,
      jacketLength: 31.0,
      collar: 17.0,
      trouserWaist: 38.0,
      trouserLength: 42.5,
      inseam: 32.0,
      thigh: 25.5,
      lapelStyle: 'Peak Lapel',
      ventStyle: 'Double Vent',
      customNotes: 'Brother wedding on 12th November. Urgent Prince Coat delivery.',
    },
    notes: 'Wedding party order coordinator. Ordered custom Emerald Prince Coat.',
    totalOrdersCount: 3,
    totalSpentPKR: 295000,
    createdAt: '2026-02-02T11:00:00Z',
    familyMembers: [
      {
        id: 'fm_3_1',
        customerId: 'cust_3',
        name: 'Bilal Chaudhry',
        relationship: 'Self',
        phone: '+92 333 5192837',
        notes: 'Primary Account Holder.',
        preferences: 'Imperial velvet, peak lapels, embroidered motifs.',
        currentMeasurements: {
          chest: 44.0,
          waist: 38.0,
          hip: 43.0,
          shoulder: 19.0,
          sleeve: 26.0,
          jacketLength: 31.0,
          collar: 17.0,
          trouserWaist: 38.0,
          trouserLength: 42.5,
          inseam: 32.0,
          thigh: 25.5,
          lapelStyle: 'Peak Lapel',
          ventStyle: 'Double Vent',
          customNotes: 'Urgent wedding fitting.',
        },
        measurementHistory: [],
        alterations: [],
        createdAt: '2026-02-02T11:00:00Z',
        updatedAt: '2026-02-02T11:00:00Z',
      },
      {
        id: 'fm_3_2',
        customerId: 'cust_3',
        name: 'Zain Chaudhry',
        relationship: 'Brother',
        phone: '+92 334 1122334',
        notes: 'Best man at the wedding. Tuxedo order.',
        preferences: 'Satin peak lapel, black worsted wool.',
        currentMeasurements: {
          chest: 40.0,
          waist: 33.0,
          hip: 39.0,
          shoulder: 18.0,
          sleeve: 25.5,
          jacketLength: 29.5,
          collar: 16.0,
          trouserWaist: 33.0,
          trouserLength: 41.0,
          inseam: 31.0,
          thigh: 23.5,
          lapelStyle: 'Peak Lapel',
          ventStyle: 'Double Vent',
          customNotes: 'Slim fit satin tuxedo.',
        },
        measurementHistory: [],
        alterations: [],
        createdAt: '2026-02-05T12:00:00Z',
        updatedAt: '2026-02-05T12:00:00Z',
      },
      {
        id: 'fm_3_3',
        customerId: 'cust_3',
        name: 'Chaudhry Shaukat Ali',
        relationship: 'Father',
        phone: '+92 333 9988776',
        notes: 'Father of the family. Classic black bespoke sherwani.',
        preferences: 'Raw silk black sherwani with gold engraved buttons.',
        currentMeasurements: {
          chest: 45.0,
          waist: 42.0,
          hip: 44.0,
          shoulder: 19.5,
          sleeve: 25.0,
          jacketLength: 42.0,
          collar: 17.5,
          trouserWaist: 42.0,
          trouserLength: 41.0,
          inseam: 30.0,
          thigh: 27.0,
          lapelStyle: 'Mandarin Collar',
          ventStyle: 'No Vent',
          customNotes: 'Sherwani fitting for grandfather presence at stage.',
        },
        measurementHistory: [],
        alterations: [],
        createdAt: '2026-02-05T12:00:00Z',
        updatedAt: '2026-02-05T12:00:00Z',
      },
    ],
  },
  {
    id: 'cust_2',
    name: 'Dr. Usman Qureshi',
    phone: '+92 321 4455821',
    email: 'dr.usman@shaukatkhanum.org.pk',
    city: 'Lahore',
    address: 'Villa 18, Sector Y, Phase 3, DHA, Lahore',
    measurements: {
      chest: 39.0,
      waist: 32.5,
      hip: 38.0,
      shoulder: 17.5,
      sleeve: 24.5,
      jacketLength: 29.0,
      collar: 15.5,
      trouserWaist: 32.5,
      trouserLength: 40.0,
      inseam: 30.0,
      thigh: 22.0,
      lapelStyle: 'Notch Lapel',
      ventStyle: 'Double Vent',
      customNotes: 'Slim fit cut requested. Tapered pant bottom opening (6.75 inches).',
    },
    notes: 'Cardiologist. Requires clean notch lapel corporate suits.',
    totalOrdersCount: 2,
    totalSpentPKR: 130000,
    createdAt: '2026-01-14T14:15:00Z',
    familyMembers: [
      {
        id: 'fm_2_1',
        customerId: 'cust_2',
        name: 'Dr. Usman Qureshi',
        relationship: 'Self',
        phone: '+92 321 4455821',
        notes: 'Consultant physician. Prefers understated luxury.',
        preferences: 'Mocha tweed, Italian lightweight wool.',
        currentMeasurements: {
          chest: 39.0,
          waist: 32.5,
          hip: 38.0,
          shoulder: 17.5,
          sleeve: 24.5,
          jacketLength: 29.0,
          collar: 15.5,
          trouserWaist: 32.5,
          trouserLength: 40.0,
          inseam: 30.0,
          thigh: 22.0,
          lapelStyle: 'Notch Lapel',
          ventStyle: 'Double Vent',
          customNotes: 'Tapered trouser hem (6.75 in).',
        },
        measurementHistory: [],
        alterations: [],
        createdAt: '2026-01-14T14:15:00Z',
        updatedAt: '2026-01-14T14:15:00Z',
      },
      {
        id: 'fm_2_2',
        customerId: 'cust_2',
        name: 'Rayyan Qureshi',
        relationship: 'Son',
        phone: '+92 321 9988112',
        notes: 'Aitchison College student. School debating blazer and formal navy suit.',
        preferences: 'Navy hopsack blazer with gilt crest buttons.',
        currentMeasurements: {
          chest: 35.0,
          waist: 28.0,
          hip: 34.0,
          shoulder: 16.0,
          sleeve: 23.5,
          jacketLength: 27.5,
          collar: 14.5,
          trouserWaist: 28.5,
          trouserLength: 38.0,
          inseam: 29.0,
          thigh: 20.5,
          lapelStyle: 'Notch Lapel',
          ventStyle: 'Double Vent',
          customNotes: 'Room for growth in sleeve cuffs (1 inch extra fabric turned in).',
        },
        measurementHistory: [],
        alterations: [],
        createdAt: '2026-03-10T10:00:00Z',
        updatedAt: '2026-03-10T10:00:00Z',
      },
    ],
  },
  {
    id: 'cust_4',
    name: 'Hamza Alvi',
    phone: '+92 345 8823190',
    email: 'hamza.alvi@fintechlahore.io',
    city: 'Karachi',
    address: 'Bungalow 77, Khayaban-e-Shamsheer, Phase 5, DHA, Karachi',
    measurements: {
      chest: 40.0,
      waist: 33.0,
      hip: 39.0,
      shoulder: 18.0,
      sleeve: 25.0,
      jacketLength: 29.5,
      collar: 16.0,
      trouserWaist: 33.0,
      trouserLength: 40.5,
      inseam: 30.5,
      thigh: 23.0,
      lapelStyle: 'Shawl Collar',
      ventStyle: 'No Vent',
      customNotes: 'Black tie gala reception event.',
    },
    notes: 'Ordered Sartorial Charcoal Tuxedo for corporate annual gala.',
    totalOrdersCount: 1,
    totalSpentPKR: 98000,
    createdAt: '2026-03-01T09:45:00Z',
    familyMembers: [
      {
        id: 'fm_4_1',
        customerId: 'cust_4',
        name: 'Hamza Alvi',
        relationship: 'Self',
        phone: '+92 345 8823190',
        preferences: 'Modern Italian tuxedo and slim cut suits.',
        currentMeasurements: {
          chest: 40.0,
          waist: 33.0,
          hip: 39.0,
          shoulder: 18.0,
          sleeve: 25.0,
          jacketLength: 29.5,
          collar: 16.0,
          trouserWaist: 33.0,
          trouserLength: 40.5,
          inseam: 30.5,
          thigh: 23.0,
          lapelStyle: 'Shawl Collar',
          ventStyle: 'No Vent',
        },
        measurementHistory: [],
        alterations: [],
        createdAt: '2026-03-01T09:45:00Z',
        updatedAt: '2026-03-01T09:45:00Z',
      },
      {
        id: 'fm_4_2',
        customerId: 'cust_4',
        name: 'Daniyal Alvi',
        relationship: 'Cousin',
        phone: '+92 345 1122998',
        preferences: 'Double-breasted navy blazer and tailored chinos.',
        currentMeasurements: {
          chest: 41.5,
          waist: 34.0,
          hip: 40.0,
          shoulder: 18.25,
          sleeve: 25.5,
          jacketLength: 30.0,
          collar: 16.25,
          trouserWaist: 34.0,
          trouserLength: 41.0,
          inseam: 31.0,
          thigh: 24.0,
          lapelStyle: 'Peak Lapel',
          ventStyle: 'Double Vent',
        },
        measurementHistory: [],
        alterations: [],
        createdAt: '2026-03-02T11:00:00Z',
        updatedAt: '2026-03-02T11:00:00Z',
      },
    ],
  },
];

// Clean initial orders (all demo records removed)
const INITIAL_ORDERS: Order[] = [];

// Sample Orders (available if user explicitly clicks "Load Sample Demo Data" in Settings)
export const SAMPLE_ORDERS: Order[] = [
  {
    id: 'ord_1',
    orderNumber: 'ZS-2026-1042',
    customerId: 'cust_1',
    customerName: 'Tariq Mehmood Bajwa',
    customerPhone: '+92 300 8472910',
    customerCity: 'Lahore',
    customerAddress: 'House 42, Block L, Gulberg III, Lahore',
    familyMemberId: 'fm_1_1',
    familyMemberName: 'Tariq Mehmood Bajwa',
    familyMemberRelationship: 'Self',
    items: [
      {
        productId: 'prod_1',
        productCode: 'ZS-701',
        title: 'Super 150s Royal Navy 3-Piece Bespoke Suit',
        fabric: 'Super 150s Merino Wool (Dormeuil England)',
        color: 'Royal Navy Blue',
        sizeOrTailoring: 'Bespoke Custom (Chest 42.5)',
        quantity: 1,
        unitPricePKR: 85000,
        totalPricePKR: 85000,
      },
    ],
    subtotalPKR: 85000,
    tailoringFeePKR: 5000,
    discountPKR: 2000,
    shippingFeePKR: 0,
    grandTotalPKR: 88000,
    advancePaidPKR: 50000,
    balanceDuePKR: 38000,
    paymentStatus: 'Partial',
    paymentMethod: 'Bank Transfer / Raast',
    status: 'In Tailoring',
    isRushOrder: false,
    eventDate: '2026-10-28',
    deliveryDate: '2026-10-25',
    measurementsSnapshot: {
      chest: 42.5,
      waist: 36.0,
      hip: 41.0,
      shoulder: 18.5,
      sleeve: 25.5,
      jacketLength: 30.0,
      collar: 16.5,
      trouserWaist: 36.0,
      trouserLength: 41.5,
      inseam: 31.0,
      thigh: 24.5,
      lapelStyle: 'Peak Lapel',
      ventStyle: 'Double Vent',
      customNotes: 'Bespoke canvas lining with padded chest piece.',
    },
    specialInstructions: 'Customer requested bespoke silk contrast buttonholes on left lapel (sky blue thread).',
    createdAt: '2026-10-10T11:20:00Z',
    updatedAt: '2026-10-14T15:40:00Z',
  },
  {
    id: 'ord_5',
    orderNumber: 'ZS-2026-1046',
    customerId: 'cust_1',
    customerName: 'Tariq Mehmood Bajwa',
    customerPhone: '+92 300 8472910',
    customerCity: 'Lahore',
    customerAddress: 'House 42, Block L, Gulberg III, Lahore',
    familyMemberId: 'fm_1_2',
    familyMemberName: 'Hamza Tariq Bajwa',
    familyMemberRelationship: 'Son',
    items: [
      {
        productId: 'prod_3',
        productCode: 'ZS-703',
        title: 'Imperial Emerald Velvet Prince Coat with Zardozi',
        fabric: 'Micro Velvet with Hand Zardozi & Antique Tilla Work',
        color: 'Deep Emerald Green',
        sizeOrTailoring: 'Bespoke Custom (Chest 38.5)',
        quantity: 1,
        unitPricePKR: 115000,
        totalPricePKR: 115000,
      },
    ],
    subtotalPKR: 115000,
    tailoringFeePKR: 5000,
    discountPKR: 5000,
    shippingFeePKR: 0,
    grandTotalPKR: 115000,
    advancePaidPKR: 70000,
    balanceDuePKR: 45000,
    paymentStatus: 'Partial',
    paymentMethod: 'Bank Transfer / Raast',
    status: 'Fitting Scheduled',
    isRushOrder: true,
    eventDate: '2026-11-12',
    deliveryDate: '2026-10-30',
    measurementsSnapshot: {
      chest: 38.5,
      waist: 31.0,
      hip: 37.5,
      shoulder: 17.5,
      sleeve: 25.0,
      jacketLength: 29.0,
      collar: 15.5,
      trouserWaist: 31.5,
      trouserLength: 40.0,
      inseam: 30.5,
      thigh: 22.5,
      lapelStyle: 'Shawl Collar',
      ventStyle: 'Double Vent',
      customNotes: 'Wedding Prince Coat. Gold dabka zardozi embroidery.',
    },
    customFieldsSnapshot: {
      'Sherwani / Prince Coat Length': 38.0,
      'Kamiz Daman Width': 22.0,
      'Pagri / Turban Head Size': 22.25,
    },
    specialInstructions: 'Bridal groom suite. Match gold zardozi embroidery with bride lehenga gold tone.',
    createdAt: '2026-10-13T14:00:00Z',
    updatedAt: '2026-10-15T12:00:00Z',
  },
  {
    id: 'ord_2',
    orderNumber: 'ZS-2026-1043',
    customerId: 'cust_3',
    customerName: 'Bilal Chaudhry',
    customerPhone: '+92 333 5192837',
    customerCity: 'Islamabad',
    customerAddress: 'Street 14, Sector F-7/2, Islamabad',
    familyMemberId: 'fm_3_1',
    familyMemberName: 'Bilal Chaudhry',
    familyMemberRelationship: 'Self',
    items: [
      {
        productId: 'prod_3',
        productCode: 'ZS-703',
        title: 'Imperial Emerald Velvet Prince Coat with Zardozi',
        fabric: 'Micro Velvet with Hand Zardozi & Antique Tilla Work',
        color: 'Deep Emerald Green',
        sizeOrTailoring: 'Bespoke Custom (Chest 44.0)',
        quantity: 1,
        unitPricePKR: 115000,
        totalPricePKR: 115000,
      },
      {
        productId: 'prod_7',
        productCode: 'ZS-707',
        title: 'Sapphire Blue Double-Breasted Waistcoat',
        fabric: 'Italian Jacquard Silk Blend',
        color: 'Sapphire Blue',
        sizeOrTailoring: '42R',
        quantity: 1,
        unitPricePKR: 26000,
        totalPricePKR: 26000,
      },
    ],
    subtotalPKR: 141000,
    tailoringFeePKR: 6000,
    discountPKR: 5000,
    shippingFeePKR: 1500,
    grandTotalPKR: 143500,
    advancePaidPKR: 143500,
    balanceDuePKR: 0,
    paymentStatus: 'Paid',
    paymentMethod: 'POS Card',
    status: 'Fitting Scheduled',
    isRushOrder: true,
    eventDate: '2026-10-24',
    deliveryDate: '2026-10-22',
    measurementsSnapshot: {
      chest: 44.0,
      waist: 38.0,
      hip: 43.0,
      shoulder: 19.0,
      sleeve: 26.0,
      jacketLength: 31.0,
      collar: 17.0,
      trouserWaist: 38.0,
      trouserLength: 42.5,
      inseam: 32.0,
      thigh: 25.5,
      lapelStyle: 'Peak Lapel',
      ventStyle: 'Double Vent',
    },
    specialInstructions: 'Trial fitting at Islamabad Serena Hotel suite on 21st Oct morning.',
    createdAt: '2026-10-11T16:00:00Z',
    updatedAt: '2026-10-15T09:10:00Z',
  },
  {
    id: 'ord_3',
    orderNumber: 'ZS-2026-1044',
    customerId: 'cust_4',
    customerName: 'Hamza Alvi',
    customerPhone: '+92 345 8823190',
    customerCity: 'Karachi',
    customerAddress: 'Bungalow 77, Khayaban-e-Shamsheer, Phase 5, DHA, Karachi',
    familyMemberId: 'fm_4_1',
    familyMemberName: 'Hamza Alvi',
    familyMemberRelationship: 'Self',
    items: [
      {
        productId: 'prod_2',
        productCode: 'ZS-702',
        title: 'Sartorial Charcoal Tuxedo with Satin Peak Lapel',
        fabric: 'Fine Worsted Wool & Grosgrain Satin',
        color: 'Midnight Charcoal Black',
        sizeOrTailoring: '40R',
        quantity: 1,
        unitPricePKR: 98000,
        totalPricePKR: 98000,
      },
    ],
    subtotalPKR: 98000,
    tailoringFeePKR: 3000,
    discountPKR: 0,
    shippingFeePKR: 2000,
    grandTotalPKR: 103000,
    advancePaidPKR: 40000,
    balanceDuePKR: 63000,
    paymentStatus: 'Partial',
    paymentMethod: 'Cash on Delivery',
    status: 'Ready for Dispatch',
    isRushOrder: false,
    eventDate: '2026-10-29',
    deliveryDate: '2026-10-20',
    measurementsSnapshot: {
      chest: 40.0,
      waist: 33.0,
      hip: 39.0,
      shoulder: 18.0,
      sleeve: 25.0,
      jacketLength: 29.5,
      collar: 16.0,
      trouserWaist: 33.0,
      trouserLength: 40.5,
      inseam: 30.5,
      thigh: 23.0,
      lapelStyle: 'Shawl Collar',
      ventStyle: 'No Vent',
    },
    specialInstructions: 'TCS Courier fragile luxury parcel with garment travel bag.',
    createdAt: '2026-10-12T10:10:00Z',
    updatedAt: '2026-10-16T08:00:00Z',
  },
  {
    id: 'ord_4',
    orderNumber: 'ZS-2026-1045',
    customerId: 'cust_2',
    customerName: 'Dr. Usman Qureshi',
    customerPhone: '+92 321 4455821',
    customerCity: 'Lahore',
    customerAddress: 'Villa 18, Sector Y, Phase 3, DHA, Lahore',
    familyMemberId: 'fm_2_1',
    familyMemberName: 'Dr. Usman Qureshi',
    familyMemberRelationship: 'Self',
    items: [
      {
        productId: 'prod_4',
        productCode: 'ZS-704',
        title: 'Scottish Mocha Herringbone Wool Tweed Suit',
        fabric: 'Mocha Herringbone Shetland Wool (380gsm)',
        color: 'Mocha Tweed',
        sizeOrTailoring: 'Bespoke Custom (Chest 39.0)',
        quantity: 1,
        unitPricePKR: 72000,
        totalPricePKR: 72000,
      },
    ],
    subtotalPKR: 72000,
    tailoringFeePKR: 4000,
    discountPKR: 3000,
    shippingFeePKR: 0,
    grandTotalPKR: 73000,
    advancePaidPKR: 73000,
    balanceDuePKR: 0,
    paymentStatus: 'Paid',
    paymentMethod: 'Bank Transfer / Raast',
    status: 'Delivered',
    isRushOrder: false,
    deliveryDate: '2026-10-15',
    measurementsSnapshot: {
      chest: 39.0,
      waist: 32.5,
      hip: 38.0,
      shoulder: 17.5,
      sleeve: 24.5,
      jacketLength: 29.0,
      collar: 15.5,
      trouserWaist: 32.5,
      trouserLength: 40.0,
      inseam: 30.0,
      thigh: 22.0,
      lapelStyle: 'Notch Lapel',
      ventStyle: 'Double Vent',
    },
    specialInstructions: 'Delivered to doctor residence in DHA Lahore. Trial fitting verified perfect.',
    createdAt: '2026-10-02T14:30:00Z',
    updatedAt: '2026-10-15T18:00:00Z',
  },
];

// Clean initial payments
const INITIAL_PAYMENTS: PaymentEntry[] = [];

// Sample Payments (available if user explicitly clicks "Load Sample Demo Data" in Settings)
export const SAMPLE_PAYMENTS: PaymentEntry[] = [
  {
    id: 'pay_1',
    orderNumber: 'ZS-2026-1042',
    customerName: 'Tariq Mehmood Bajwa',
    amountPKR: 50000,
    type: 'Advance Deposit',
    method: 'Raast / Online Bank',
    referenceNumber: 'RAAST-991204882',
    date: '2026-10-10 11:45',
    recordedBy: 'Mian Zubair Tariq',
  },
  {
    id: 'pay_2',
    orderNumber: 'ZS-2026-1043',
    customerName: 'Bilal Chaudhry',
    amountPKR: 143500,
    type: 'Full Payment',
    method: 'POS Debit/Credit Card',
    referenceNumber: 'HBL-POS-440192',
    date: '2026-10-11 16:30',
    recordedBy: 'Hamza Farooq',
  },
  {
    id: 'pay_3',
    orderNumber: 'ZS-2026-1044',
    customerName: 'Hamza Alvi',
    amountPKR: 40000,
    type: 'Advance Deposit',
    method: 'Cash',
    referenceNumber: 'REC-0821',
    date: '2026-10-12 10:45',
    recordedBy: 'Hamza Farooq',
  },
  {
    id: 'pay_4',
    orderNumber: 'ZS-2026-1045',
    customerName: 'Dr. Usman Qureshi',
    amountPKR: 73000,
    type: 'Full Payment',
    method: 'Raast / Online Bank',
    referenceNumber: 'RAAST-330192081',
    date: '2026-10-02 15:10',
    recordedBy: 'Mian Zubair Tariq',
  },
];

// Clean initial expenses
const INITIAL_EXPENSES: ExpenseEntry[] = [];

// Sample Expenses (available if user explicitly clicks "Load Sample Demo Data" in Settings)
export const SAMPLE_EXPENSES: ExpenseEntry[] = [
  {
    id: 'exp_1',
    category: 'Fabric & Lining Procurement',
    description: '30 meters Super 150s Dormeuil Navy & Black Wool batch imported via Lahore Air Cargo',
    amountPKR: 285000,
    date: '2026-10-05',
    paymentMethod: 'Bank Transfer',
    vendorName: 'Al-Madina Fine Fabrics Mall Road',
    receiptNumber: 'AMF-8821',
    recordedBy: 'Mian Zubair Tariq',
  },
  {
    id: 'exp_2',
    category: 'Tailor Master Wages',
    description: 'Weekly tailoring master craftsmanship wages (Master Aslam & team of 4 artisans)',
    amountPKR: 85000,
    date: '2026-10-12',
    paymentMethod: 'Cash',
    vendorName: 'Master Aslam (Head Cutter)',
    receiptNumber: 'WAGE-WK41',
    recordedBy: 'Mian Zubair Tariq',
  },
  {
    id: 'exp_3',
    category: 'Packaging & Suit Covers',
    description: '150 custom branded luxury garment travel bags with brass zippers and wooden hangers',
    amountPKR: 48000,
    date: '2026-10-08',
    paymentMethod: 'Cash',
    vendorName: 'Royal Packaging Anarkali Lahore',
    receiptNumber: 'RP-441',
    recordedBy: 'Hamza Farooq',
  },
  {
    id: 'exp_4',
    category: 'Showroom Rent & Utilities',
    description: 'Monthly electricity bill (LESCO Commercial) & Atelier maintenance Gulberg III',
    amountPKR: 62000,
    date: '2026-10-01',
    paymentMethod: 'Online Bank',
    vendorName: 'LESCO',
    receiptNumber: 'LES-99214',
    recordedBy: 'Mian Zubair Tariq',
  },
];

// Clean initial WhatsApp conversations
const INITIAL_WHATSAPP: WhatsAppConversation[] = [];

// Sample WhatsApp conversations (available if user explicitly clicks "Load Sample Demo Data" in Settings)
export const SAMPLE_WHATSAPP: WhatsAppConversation[] = [
  {
    id: 'conv_1',
    customerId: 'cust_1',
    customerName: 'Tariq Mehmood Bajwa',
    customerPhone: '+92 300 8472910',
    unreadCount: 0,
    lastMessage: 'AOA Mian Sahab, buttonholes color is perfect. Let me know when ready for trial.',
    lastTimestamp: 'Yesterday 17:42',
    orderNumberRef: 'ZS-2026-1042',
    messages: [
      {
        id: 'msg_1',
        conversationId: 'conv_1',
        sender: 'business',
        text: 'Assalam-o-Alaikum Bajwa Sahab! Your order ZS-2026-1042 for the Super 150s Navy 3-Piece Bespoke Suit is currently undergoing canvassing with Master Aslam.',
        timestamp: '2026-10-14 11:30',
        status: 'read',
      },
      {
        id: 'msg_2',
        conversationId: 'conv_1',
        sender: 'customer',
        text: 'Walaikum Assalam. Did you note the light blue contrast thread on the lapel buttonhole?',
        timestamp: '2026-10-14 12:05',
        status: 'read',
      },
      {
        id: 'msg_3',
        conversationId: 'conv_1',
        sender: 'business',
        text: 'Yes sir, absolutely! Hand-stitched Milanese buttonhole with imported Gutermann sky blue silk thread. We will schedule fitting for Tuesday.',
        timestamp: '2026-10-14 14:10',
        status: 'read',
      },
      {
        id: 'msg_4',
        conversationId: 'conv_1',
        sender: 'customer',
        text: 'AOA Mian Sahab, buttonholes color is perfect. Let me know when ready for trial.',
        timestamp: '2026-10-15 17:42',
        status: 'read',
      },
    ],
  },
  {
    id: 'conv_2',
    customerId: 'cust_3',
    customerName: 'Bilal Chaudhry',
    customerPhone: '+92 333 5192837',
    unreadCount: 1,
    lastMessage: 'Can you bring the sapphire waistcoat to Serena on 21st as well?',
    lastTimestamp: 'Today 10:15',
    orderNumberRef: 'ZS-2026-1043',
    messages: [
      {
        id: 'msg_5',
        conversationId: 'conv_2',
        sender: 'business',
        text: 'Respected Bilal Sahab, your Emerald Velvet Prince Coat Zardozi embroidery has passed quality inspection. Fitting scheduled for Serena Hotel Islamabad.',
        timestamp: '2026-10-15 15:00',
        status: 'read',
      },
      {
        id: 'msg_6',
        conversationId: 'conv_2',
        sender: 'customer',
        text: 'JazakAllah! The embroidery looks exquisite in the photos you sent.',
        timestamp: '2026-10-15 15:45',
        status: 'read',
      },
      {
        id: 'msg_7',
        conversationId: 'conv_2',
        sender: 'customer',
        text: 'Can you bring the sapphire waistcoat to Serena on 21st as well?',
        timestamp: '2026-10-16 10:15',
        status: 'delivered',
      },
    ],
  },
  {
    id: 'conv_3',
    customerId: 'cust_4',
    customerName: 'Hamza Alvi',
    customerPhone: '+92 345 8823190',
    unreadCount: 0,
    lastMessage: 'Tracking number received. Thank you for dispatching so quickly!',
    lastTimestamp: 'Today 09:20',
    orderNumberRef: 'ZS-2026-1044',
    messages: [
      {
        id: 'msg_8',
        conversationId: 'conv_3',
        sender: 'business',
        text: 'Dear Mr. Hamza, your Sartorial Charcoal Tuxedo (ZS-2026-1044) has been packed in our luxury suit carrier and booked via TCS Express to DHA Karachi.',
        timestamp: '2026-10-16 08:30',
        status: 'read',
      },
      {
        id: 'msg_9',
        conversationId: 'conv_3',
        sender: 'customer',
        text: 'Tracking number received. Thank you for dispatching so quickly!',
        timestamp: '2026-10-16 09:20',
        status: 'read',
      },
    ],
  },
];

// Clean Initial Audit Logs
const INITIAL_AUDIT_LOGS: AuditLog[] = [
  {
    id: 'log_init',
    timestamp: '2026-10-17 06:40',
    userName: 'System Admin',
    userRole: 'ADMIN',
    action: 'DATABASE_INITIALIZED',
    details: 'All demo data removed. Production suit business ERP is online and ready.',
    entityType: 'AUTH',
  },
];

// Sample Audit Logs (available if user explicitly loads demo samples)
export const SAMPLE_AUDIT_LOGS: AuditLog[] = [
  {
    id: 'log_1',
    timestamp: '2026-10-16 08:00',
    userName: 'Hamza Farooq',
    userRole: 'EMPLOYEE',
    action: 'ORDER_STATUS_UPDATE',
    details: 'Updated Order #ZS-2026-1044 status to Ready for Dispatch',
    entityType: 'ORDER',
  },
  {
    id: 'log_2',
    timestamp: '2026-10-15 18:00',
    userName: 'Mian Zubair Tariq',
    userRole: 'ADMIN',
    action: 'ORDER_DELIVERY_CONFIRMED',
    details: 'Order #ZS-2026-1045 marked as Delivered to Dr. Usman Qureshi in DHA Lahore',
    entityType: 'ORDER',
  },
  {
    id: 'log_3',
    timestamp: '2026-10-15 09:10',
    userName: 'Mian Zubair Tariq',
    userRole: 'ADMIN',
    action: 'FITTING_SCHEDULED',
    details: 'Scheduled VIP hotel suite fitting for Order #ZS-2026-1043 at Serena Islamabad',
    entityType: 'ORDER',
  },
  {
    id: 'log_4',
    timestamp: '2026-10-12 10:45',
    userName: 'Hamza Farooq',
    userRole: 'EMPLOYEE',
    action: 'PAYMENT_RECORDED',
    details: 'Recorded Advance Deposit PKR 40,000 for Order #ZS-2026-1044',
    entityType: 'PAYMENT',
  },
  {
    id: 'log_5',
    timestamp: '2026-10-11 16:30',
    userName: 'Hamza Farooq',
    userRole: 'EMPLOYEE',
    action: 'ORDER_CREATED',
    details: 'Created rush order #ZS-2026-1043 for wedding client Bilal Chaudhry',
    entityType: 'ORDER',
  },
];

// Clean Initial Notifications
const INITIAL_NOTIFICATIONS: SystemNotification[] = [
  {
    id: 'notif_welcome',
    title: 'Welcome to Atelier ERP',
    message: 'All demo data has been removed. You can now add your own suit products, clients, family members, and website in Settings.',
    timestamp: 'Just now',
    type: 'ai',
    read: false,
    linkTab: 'products',
  },
];

// Sample Notifications
export const SAMPLE_NOTIFICATIONS: SystemNotification[] = [
  {
    id: 'notif_1',
    title: 'Trial Fitting Due Today',
    message: 'Trial fitting scheduled for Prince Coat #ZS-2026-1043 (Bilal Chaudhry) today.',
    timestamp: '15 mins ago',
    type: 'fitting',
    read: false,
    linkTab: 'orders',
    targetId: 'ord_2',
  },
  {
    id: 'notif_2',
    title: 'Low Stock Alert',
    message: 'Vanquish Jet Black 2-Piece (ZS-705) has reached minimum threshold of 2 suits.',
    timestamp: '1 hour ago',
    type: 'inventory',
    read: false,
    linkTab: 'products',
    targetId: 'prod_5',
  },
  {
    id: 'notif_3',
    title: 'COD Dispatch Pending',
    message: 'Order #ZS-2026-1044 is ready for courier hand-over with COD balance PKR 63,000.',
    timestamp: '2 hours ago',
    type: 'order',
    read: false,
    linkTab: 'orders',
    targetId: 'ord_3',
  },
  {
    id: 'notif_4',
    title: 'Advance Payment Received',
    message: 'Raast payment of PKR 50,000 confirmed for Order #ZS-2026-1042.',
    timestamp: 'Yesterday',
    type: 'payment',
    read: true,
    linkTab: 'finance',
    targetId: 'pay_1',
  },
];

// Clean Initial Printer & Business Identity Configuration (All demo data removed)
const INITIAL_PRINTER_CONFIG: ThermalPrinterConfig = {
  paperWidth: '80mm',
  businessName: '',
  tagline: '',
  address: '',
  city: '',
  phone: '',
  websiteUrl: '',
  ntnNumber: '',
  footerNote: '',
  printBarcode: true,
  cutPaperAfterPrint: true,
  autoSaveEnabled: true,
};

// Clean WhatsApp Config (All demo credentials removed)
const INITIAL_WHATSAPP_CONFIG: WhatsAppCloudApiConfig = {
  mode: 'DEMO',
  phoneNumberId: '',
  businessAccountId: '',
  permanentAccessToken: '',
  webhookVerifyToken: '',
  isConnected: false,
};

// Helper to mask sensitive customer data for employees (Salesperson only sees name, never number)
export function maskPhoneNumber(phone: string): string {
  if (!phone) return '';
  return '••••••••••••';
}

export function maskAddress(address: string): string {
  if (!address) return '';
  // Retain city/neighborhood, mask specific house/plot:
  const parts = address.split(',');
  if (parts.length > 1) {
    const area = parts[parts.length - 2]?.trim() || '';
    const city = parts[parts.length - 1]?.trim() || '';
    return `[Restricted House No.], ${area}, ${city}`;
  }
  return '[Restricted Client Address]';
}

class DemoDatabaseService {
  private getItem<T>(key: string, defaultValue: T): T {
    try {
      const data = localStorage.getItem(key);
      if (!data) {
        localStorage.setItem(key, JSON.stringify(defaultValue));
        return defaultValue;
      }
      return JSON.parse(data) as T;
    } catch {
      return defaultValue;
    }
  }

  private setItem<T>(key: string, value: T): void {
    try {
      localStorage.setItem(key, JSON.stringify(value));
    } catch (err) {
      console.error(`Failed to save to localStorage key ${key}:`, err);
    }
  }

  // Current logged in demo user
  getCurrentUser(): UserAccount {
    return this.getItem<UserAccount>(STORAGE_KEYS.CURRENT_USER, ADMIN_USER);
  }

  setCurrentUser(user: UserAccount): void {
    this.setItem(STORAGE_KEYS.CURRENT_USER, user);
    this.addAuditLog({
      userName: user.name,
      userRole: user.role,
      action: 'AUTH_SWITCH_USER',
      details: `Switched active session to ${user.name} (${user.role})`,
      entityType: 'AUTH',
    });
  }

  // USER ACCOUNTS & RBAC MANAGEMENT
  getUsers(): UserAccount[] {
    const users = this.getItem<UserAccount[]>(STORAGE_KEYS.USERS, INITIAL_USERS);
    // Ensure admin user and employee user have passwords and allowedViews if legacy data existed
    let modified = false;
    users.forEach((u) => {
      if (u.id === ADMIN_USER.id) {
        if (!u.username) { u.username = 'admin'; modified = true; }
        if (!u.password) { u.password = 'admin123'; modified = true; }
        if (u.name === 'Mian Zubair Tariq') { u.name = 'Administrator'; modified = true; }
        if (u.permissions.allowedViews && u.permissions.allowedViews.includes('production')) {
          u.permissions.allowedViews = u.permissions.allowedViews.filter((v) => v !== 'production');
          modified = true;
        }
        if (!u.permissions.allowedViews) {
          u.permissions.allowedViews = ['dashboard', 'orders', 'products', 'customers', 'thermal', 'finance', 'settings', 'audit'];
          modified = true;
        }
      } else if (u.id === EMPLOYEE_USER.id) {
        if (!u.username) { u.username = 'sales'; modified = true; }
        if (!u.password) { u.password = 'sales123'; modified = true; }
        if (u.permissions.allowedViews && u.permissions.allowedViews.includes('production')) {
          u.permissions.allowedViews = u.permissions.allowedViews.filter((v) => v !== 'production');
          modified = true;
        }
        if (!u.permissions.allowedViews) {
          u.permissions.allowedViews = ['orders', 'products', 'customers', 'thermal'];
          modified = true;
        }
      }
    });
    if (modified) {
      this.setItem(STORAGE_KEYS.USERS, users);
    }
    return users;
  }

  getUserById(id: string): UserAccount | null {
    const users = this.getUsers();
    return users.find((u) => u.id === id) || null;
  }

  getUserByUsernameOrEmail(identifier: string): UserAccount | null {
    const clean = identifier.trim().toLowerCase();
    const users = this.getUsers();
    return users.find((u) => (u.username && u.username.toLowerCase() === clean) || (u.email && u.email.toLowerCase() === clean)) || null;
  }

  // Create new sales login with custom information visibility settings
  createSalesUser(
    userData: {
      name: string;
      username: string;
      email: string;
      password: string;
      title: string;
      permissions: UserAccount['permissions'];
    },
    adminUser: UserAccount
  ): UserAccount {
    if (adminUser.role !== 'ADMIN') {
      throw new Error('Access Denied: Only Administrator can generate sales staff logins.');
    }

    const cleanUsername = userData.username.trim().toLowerCase();
    const users = this.getUsers();
    if (users.some((u) => u.username?.toLowerCase() === cleanUsername)) {
      throw new Error(`Username "${userData.username}" is already taken. Please choose another username.`);
    }

    const newUser: UserAccount = {
      id: `usr_sales_${Date.now()}`,
      name: userData.name.trim(),
      username: cleanUsername,
      email: userData.email.trim().toLowerCase() || `${cleanUsername}@sartoriallibas.pk`,
      password: userData.password.trim(),
      role: 'EMPLOYEE',
      title: userData.title.trim() || 'Showroom Sales Associate',
      createdAt: new Date().toISOString().slice(0, 10),
      permissions: {
        ...userData.permissions,
        canManageSettings: false,
        canDeleteRecords: false,
        canExportData: false,
      },
    };

    users.push(newUser);
    this.setItem(STORAGE_KEYS.USERS, users);

    this.addAuditLog({
      userName: adminUser.name,
      userRole: adminUser.role,
      action: 'SALESPERSON_ACCOUNT_CREATED',
      details: `Generated new sales login for ${newUser.name} (@${newUser.username}) with customized visibility settings.`,
      entityType: 'AUTH',
    });

    return newUser;
  }

  // Update sales staff or admin profile, password, or hidden information settings
  updateSalesUser(
    id: string,
    updates: Partial<UserAccount>,
    adminUser: UserAccount
  ): UserAccount | null {
    if (adminUser.role !== 'ADMIN') {
      throw new Error('Access Denied: Only Administrator can modify staff credentials and permissions.');
    }

    const users = this.getUsers();
    const index = users.findIndex((u) => u.id === id);
    if (index === -1) return null;

    if (id === ADMIN_USER.id && updates.role && updates.role !== 'ADMIN') {
      throw new Error('Cannot downgrade primary Administrator account.');
    }

    if (updates.username) {
      const cleanUsername = updates.username.trim().toLowerCase();
      const existing = users.find((u) => u.id !== id && u.username?.toLowerCase() === cleanUsername);
      if (existing) {
        throw new Error(`Username "${cleanUsername}" is already taken by another account.`);
      }
      updates.username = cleanUsername;
    }

    users[index] = {
      ...users[index],
      ...updates,
      permissions: {
        ...users[index].permissions,
        ...(updates.permissions || {}),
      },
    };

    this.setItem(STORAGE_KEYS.USERS, users);

    const currentUser = this.getCurrentUser();
    if (currentUser.id === id) {
      this.setItem(STORAGE_KEYS.CURRENT_USER, users[index]);
    }

    this.addAuditLog({
      userName: adminUser.name,
      userRole: adminUser.role,
      action: id === ADMIN_USER.id ? 'ADMIN_PROFILE_UPDATED' : 'SALESPERSON_ACCOUNT_UPDATED',
      details: id === ADMIN_USER.id
        ? `Updated Admin credentials & ID: @${users[index].username} (${users[index].name})`
        : `Updated credentials & visibility permissions for ${users[index].name} (@${users[index].username}).`,
      entityType: 'AUTH',
    });

    return users[index];
  }

  // Delete sales staff login
  deleteSalesUser(id: string, adminUser: UserAccount): boolean {
    if (adminUser.role !== 'ADMIN') {
      throw new Error('Access Denied: Only Administrator can remove staff logins.');
    }

    if (id === ADMIN_USER.id) {
      throw new Error('Security Restriction: Primary Administrator account cannot be deleted.');
    }

    const users = this.getUsers();
    const target = users.find((u) => u.id === id);
    if (!target) return false;

    const filtered = users.filter((u) => u.id !== id);
    this.setItem(STORAGE_KEYS.USERS, filtered);

    const currentUser = this.getCurrentUser();
    if (currentUser.id === id) {
      this.setItem(STORAGE_KEYS.CURRENT_USER, ADMIN_USER);
      this.setSessionAuthenticated(false);
    }

    this.addAuditLog({
      userName: adminUser.name,
      userRole: adminUser.role,
      action: 'SALESPERSON_ACCOUNT_DELETED',
      details: `Deleted sales login for ${target.name} (@${target.username}).`,
      entityType: 'AUTH',
    });

    return true;
  }

  // MANDATORY PASSWORD AUTHENTICATION GATEWAY
  authenticateUser(
    identifier: string,
    passwordInput: string
  ): { success: boolean; user?: UserAccount; error?: string } {
    const cleanId = (identifier || '').trim().toLowerCase();
    const cleanPw = (passwordInput || '').trim();

    if (!cleanId) {
      return { success: false, error: 'Please enter your username or email address.' };
    }

    if (!cleanPw) {
      return { success: false, error: 'Password is required. You cannot log in without entering your password.' };
    }

    const user = this.getUserByUsernameOrEmail(cleanId);
    if (!user) {
      this.addAuditLog({
        userName: cleanId,
        userRole: 'EMPLOYEE',
        action: 'AUTH_LOGIN_FAILED',
        details: `Failed login attempt for non-existent account: "${cleanId}"`,
        entityType: 'AUTH',
      });
      return { success: false, error: 'Account not found. Please verify your username.' };
    }

    // Strictly verify password!
    if (user.password !== cleanPw) {
      this.addAuditLog({
        userName: user.name,
        userRole: user.role,
        action: 'AUTH_LOGIN_FAILED',
        details: `Failed login attempt (incorrect password) for account: @${user.username}`,
        entityType: 'AUTH',
      });
      return { success: false, error: 'Incorrect password. Access denied. Password required to log in.' };
    }

    // Success!
    this.setItem(STORAGE_KEYS.CURRENT_USER, user);
    this.setSessionAuthenticated(true, user);

    this.addAuditLog({
      userName: user.name,
      userRole: user.role,
      action: 'AUTH_LOGIN_SUCCESS',
      details: `User @${user.username} (${user.name}) successfully authenticated with password.`,
      entityType: 'AUTH',
    });

    return { success: true, user };
  }

  // SESSION STATUS
  isSessionAuthenticated(): boolean {
    try {
      const auth = localStorage.getItem(STORAGE_KEYS.AUTH_SESSION);
      return auth === 'true';
    } catch {
      return false;
    }
  }

  setSessionAuthenticated(authenticated: boolean, user?: UserAccount): void {
    try {
      localStorage.setItem(STORAGE_KEYS.AUTH_SESSION, authenticated ? 'true' : 'false');
      if (authenticated && user) {
        this.setItem(STORAGE_KEYS.CURRENT_USER, user);
      }
    } catch (err) {
      console.error('Failed to update session auth flag:', err);
    }
  }

  logoutUser(user?: UserAccount): void {
    const active = user || this.getCurrentUser();
    this.setSessionAuthenticated(false);
    this.addAuditLog({
      userName: active?.name || 'Active Session',
      userRole: active?.role || 'EMPLOYEE',
      action: 'AUTH_LOGOUT',
      details: `User @${active?.username || 'user'} logged out. App locked until password is provided.`,
      entityType: 'AUTH',
    });
  }

  // PRODUCTS
  getProducts(): Product[] {
    return this.getItem<Product[]>(STORAGE_KEYS.PRODUCTS, INITIAL_PRODUCTS);
  }

  addProduct(productData: Omit<Product, 'id'>, user: UserAccount): Product {
    const products = this.getProducts();
    const newProduct: Product = {
      ...productData,
      id: `prod_${Date.now()}`,
    };
    products.unshift(newProduct);
    this.setItem(STORAGE_KEYS.PRODUCTS, products);

    this.addAuditLog({
      userName: user.name,
      userRole: user.role,
      action: 'PRODUCT_CREATED',
      details: `Added new product ${newProduct.code} - ${newProduct.title} (Stock: ${newProduct.stockQty})`,
      entityType: 'PRODUCT',
    });

    return newProduct;
  }

  updateProduct(productId: string, updates: Partial<Product>, user: UserAccount): Product | null {
    const products = this.getProducts();
    const index = products.findIndex((p) => p.id === productId);
    if (index === -1) return null;

    products[index] = { ...products[index], ...updates };
    this.setItem(STORAGE_KEYS.PRODUCTS, products);

    this.addAuditLog({
      userName: user.name,
      userRole: user.role,
      action: 'PRODUCT_UPDATED',
      details: `Updated product ${products[index].code} (${products[index].title})`,
      entityType: 'PRODUCT',
    });

    return products[index];
  }

  updateStock(productId: string, delta: number, reason: string, user: UserAccount): Product | null {
    const products = this.getProducts();
    const index = products.findIndex((p) => p.id === productId);
    if (index === -1) return null;

    const oldQty = products[index].stockQty;
    const newQty = Math.max(0, oldQty + delta);
    products[index].stockQty = newQty;
    this.setItem(STORAGE_KEYS.PRODUCTS, products);

    this.addAuditLog({
      userName: user.name,
      userRole: user.role,
      action: 'STOCK_ADJUSTMENT',
      details: `Adjusted stock for ${products[index].code} by ${delta > 0 ? '+' : ''}${delta} (${oldQty} -> ${newQty}). Reason: ${reason}`,
      entityType: 'PRODUCT',
    });

    if (newQty <= products[index].minStockAlert) {
      this.addNotification({
        title: 'Low Stock Alert',
        message: `${products[index].title} (${products[index].code}) is low: ${newQty} remaining.`,
        type: 'inventory',
        linkTab: 'products',
        targetId: productId,
      });
    }

    return products[index];
  }

  deleteProduct(productId: string, user: UserAccount): boolean {
    if (user.role !== 'ADMIN') {
      throw new Error('Access Denied: Only Admins can delete products.');
    }
    const products = this.getProducts();
    const target = products.find((p) => p.id === productId);
    const filtered = products.filter((p) => p.id !== productId);
    this.setItem(STORAGE_KEYS.PRODUCTS, filtered);

    if (target) {
      this.addAuditLog({
        userName: user.name,
        userRole: user.role,
        action: 'PRODUCT_DELETED',
        details: `Deleted product ${target.code} (${target.title})`,
        entityType: 'PRODUCT',
      });
    }
    return true;
  }

  // ORDERS WITH DATA-LAYER ROLE ENFORCEMENT
  getOrders(userRole: UserRole): Order[] {
    const orders = this.getItem<Order[]>(STORAGE_KEYS.ORDERS, INITIAL_ORDERS);

    if (userRole === 'EMPLOYEE') {
      // Backend-level data layer masking
      return orders.map((ord) => ({
        ...ord,
        customerPhone: maskPhoneNumber(ord.customerPhone),
        customerAddress: maskAddress(ord.customerAddress),
      }));
    }

    return orders;
  }

  getOrderById(orderId: string, userRole: UserRole): Order | null {
    const orders = this.getOrders(userRole);
    return orders.find((o) => o.id === orderId) || null;
  }

  createOrder(orderData: Omit<Order, 'id' | 'orderNumber' | 'createdAt' | 'updatedAt'>, user: UserAccount): Order {
    const orders = this.getItem<Order[]>(STORAGE_KEYS.ORDERS, INITIAL_ORDERS);
    const timestamp = Date.now();
    const orderNumber = `ZS-2026-${1040 + orders.length + 1}`;

    const newOrder: Order = {
      ...orderData,
      id: `ord_${timestamp}`,
      orderNumber,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    orders.unshift(newOrder);
    this.setItem(STORAGE_KEYS.ORDERS, orders);

    // Apply configured stock rules: decrement stock for selected items
    const products = this.getProducts();
    for (const item of newOrder.items) {
      const pIdx = products.findIndex((p) => p.id === item.productId);
      if (pIdx !== -1) {
        products[pIdx].stockQty = Math.max(0, products[pIdx].stockQty - item.quantity);
      }
    }
    this.setItem(STORAGE_KEYS.PRODUCTS, products);

    // If advance payment was made, record payment entry
    if (newOrder.advancePaidPKR > 0) {
      this.recordPayment({
        orderNumber: newOrder.orderNumber,
        customerName: newOrder.customerName,
        amountPKR: newOrder.advancePaidPKR,
        type: newOrder.advancePaidPKR >= newOrder.grandTotalPKR ? 'Full Payment' : 'Advance Deposit',
        method: newOrder.paymentMethod === 'Bank Transfer / Raast' ? 'Raast / Online Bank' : (newOrder.paymentMethod === 'POS Card' ? 'POS Debit/Credit Card' : 'Cash'),
        referenceNumber: `INIT-${timestamp.toString().slice(-6)}`,
        date: new Date().toISOString().slice(0, 16).replace('T', ' '),
        recordedBy: user.name,
      }, user);
    }

    // Update customer stats
    this.updateCustomerSpend(newOrder.customerId, newOrder.grandTotalPKR);

    this.addAuditLog({
      userName: user.name,
      userRole: user.role,
      action: 'ORDER_CREATED',
      details: `Created Order #${orderNumber} for ${newOrder.customerName}. Total PKR ${newOrder.grandTotalPKR.toLocaleString()} (Items: ${newOrder.items.length})`,
      entityType: 'ORDER',
    });

    this.addNotification({
      title: 'New Suit Order Placed',
      message: `Order #${orderNumber} created for ${newOrder.customerName}. Delivery: ${newOrder.deliveryDate}`,
      type: 'order',
      linkTab: 'orders',
      targetId: newOrder.id,
    });

    return newOrder;
  }

  updateOrderStatus(orderId: string, newStatus: OrderStatus, user: UserAccount): Order | null {
    const orders = this.getItem<Order[]>(STORAGE_KEYS.ORDERS, INITIAL_ORDERS);
    const index = orders.findIndex((o) => o.id === orderId);
    if (index === -1) return null;

    const oldStatus = orders[index].status;
    orders[index].status = newStatus;
    orders[index].updatedAt = new Date().toISOString();
    this.setItem(STORAGE_KEYS.ORDERS, orders);

    this.addAuditLog({
      userName: user.name,
      userRole: user.role,
      action: 'ORDER_STATUS_UPDATE',
      details: `Order #${orders[index].orderNumber} status changed from "${oldStatus}" to "${newStatus}"`,
      entityType: 'ORDER',
    });

    this.addNotification({
      title: `Order #${orders[index].orderNumber} Status Updated`,
      message: `Suit order is now: ${newStatus}`,
      type: 'order',
      linkTab: 'orders',
      targetId: orderId,
    });

    return orders[index];
  }

  cancelOrder(orderId: string, restockInventory: boolean, reason: string, user: UserAccount): Order | null {
    const orders = this.getItem<Order[]>(STORAGE_KEYS.ORDERS, INITIAL_ORDERS);
    const index = orders.findIndex((o) => o.id === orderId);
    if (index === -1) return null;

    const targetOrder = orders[index];
    targetOrder.status = 'Cancelled';
    targetOrder.updatedAt = new Date().toISOString();
    this.setItem(STORAGE_KEYS.ORDERS, orders);

    if (restockInventory) {
      const products = this.getProducts();
      for (const item of targetOrder.items) {
        const pIdx = products.findIndex((p) => p.id === item.productId);
        if (pIdx !== -1) {
          products[pIdx].stockQty += item.quantity;
        }
      }
      this.setItem(STORAGE_KEYS.PRODUCTS, products);
    }

    this.addAuditLog({
      userName: user.name,
      userRole: user.role,
      action: 'ORDER_CANCELLED',
      details: `Cancelled Order #${targetOrder.orderNumber}. Restocked: ${restockInventory ? 'YES' : 'NO'}. Reason: ${reason}`,
      entityType: 'ORDER',
    });

    return targetOrder;
  }

  // CUSTOMERS & FAMILY MANAGEMENT WITH ROLE-BASED ACCESS
  getCustomers(userRole: UserRole): Customer[] {
    let customers = this.getItem<Customer[]>(STORAGE_KEYS.CUSTOMERS, INITIAL_CUSTOMERS);

    // Auto-migration: ensure existing stored customers have familyMembers populated
    let migrated = false;
    customers = customers.map((c) => {
      if (!c.familyMembers || c.familyMembers.length === 0) {
        migrated = true;
        const seedCust = INITIAL_CUSTOMERS.find((sc) => sc.id === c.id);
        if (seedCust && seedCust.familyMembers && seedCust.familyMembers.length > 0) {
          return { ...c, familyMembers: seedCust.familyMembers };
        }
        // Fallback default Self member
        return {
          ...c,
          familyMembers: [
            {
              id: `fm_${c.id}_self`,
              customerId: c.id,
              name: c.name,
              relationship: 'Self',
              phone: c.phone,
              notes: 'Primary Account Holder',
              preferences: 'Bespoke hand-crafted suits',
              currentMeasurements: c.measurements || {
                chest: 40.0,
                waist: 34.0,
                hip: 40.0,
                shoulder: 18.0,
                sleeve: 25.0,
                jacketLength: 30.0,
                collar: 16.0,
                trouserWaist: 34.0,
                trouserLength: 41.0,
                inseam: 31.0,
                thigh: 24.0,
                lapelStyle: 'Peak Lapel',
                ventStyle: 'Double Vent',
              },
              measurementHistory: [],
              alterations: [],
              isArchived: false,
              createdAt: c.createdAt,
              updatedAt: c.createdAt,
            },
          ],
        };
      }
      return c;
    });

    if (migrated) {
      this.setItem(STORAGE_KEYS.CUSTOMERS, customers);
    }

    if (userRole === 'EMPLOYEE') {
      return customers.map((c) => ({
        ...c,
        phone: maskPhoneNumber(c.phone),
        address: maskAddress(c.address),
        notes: '[Employee Restricted Notes]',
        familyMembers: c.familyMembers?.map((fm) => ({
          ...fm,
          phone: fm.phone ? maskPhoneNumber(fm.phone) : undefined,
          notes: fm.notes ? '[Employee Restricted Notes]' : undefined,
        })),
      }));
    }

    return customers;
  }

  getCities(): string[] {
    const storedCities = this.getItem<string[]>(STORAGE_KEYS.CITIES, DEFAULT_CITIES);
    const customers = this.getItem<Customer[]>(STORAGE_KEYS.CUSTOMERS, INITIAL_CUSTOMERS);
    const all = new Set<string>([...DEFAULT_CITIES, ...storedCities]);
    customers.forEach((c) => {
      if (c.city && typeof c.city === 'string' && c.city.trim()) {
        all.add(c.city.trim());
      }
      if (c.familyMembers) {
        c.familyMembers.forEach((fm) => {
          if (fm.city && typeof fm.city === 'string' && fm.city.trim()) {
            all.add(fm.city.trim());
          }
        });
      }
    });
    return Array.from(all);
  }

  addCity(newCity: string, user?: UserAccount): string[] {
    const cleanCity = newCity.trim();
    if (!cleanCity) return this.getCities();
    const storedCities = this.getItem<string[]>(STORAGE_KEYS.CITIES, DEFAULT_CITIES);
    if (!storedCities.some((c) => c.toLowerCase() === cleanCity.toLowerCase())) {
      storedCities.push(cleanCity);
      this.setItem(STORAGE_KEYS.CITIES, storedCities);
      if (user) {
        this.addAuditLog({
          userName: user.name,
          userRole: user.role,
          action: 'CITY_REGISTERED',
          details: `Registered new operating city in atelier system: ${cleanCity}`,
          entityType: 'SETTINGS',
        });
      }
    }
    return this.getCities();
  }

  getCustomerById(customerId: string, userRole: UserRole): Customer | null {
    const customers = this.getCustomers(userRole);
    return customers.find((c) => c.id === customerId) || null;
  }

  addCustomer(
    customerData: Omit<Customer, 'id' | 'totalOrdersCount' | 'totalSpentPKR' | 'createdAt'>,
    user: UserAccount
  ): Customer {
    const customers = this.getItem<Customer[]>(STORAGE_KEYS.CUSTOMERS, INITIAL_CUSTOMERS);
    const newCustId = `cust_${Date.now()}`;
    const nowIso = new Date().toISOString();

    // Ensure custom city is registered in system cities
    if (customerData.city && typeof customerData.city === 'string' && customerData.city.trim()) {
      this.addCity(customerData.city.trim());
    }

    // Automatically initialize 'Self' primary family member
    const defaultSelfMember: FamilyMember = {
      id: `fm_${Date.now()}_self`,
      customerId: newCustId,
      name: customerData.name,
      relationship: 'Self',
      phone: customerData.phone,
      city: customerData.city,
      notes: customerData.notes || 'Primary Account Holder',
      preferences: 'Bespoke custom fit',
      currentMeasurements: customerData.measurements || {
        chest: 40.0,
        waist: 34.0,
        hip: 40.0,
        shoulder: 18.0,
        sleeve: 25.0,
        jacketLength: 30.0,
        collar: 16.0,
        trouserWaist: 34.0,
        trouserLength: 41.0,
        inseam: 31.0,
        thigh: 24.0,
        lapelStyle: 'Peak Lapel',
        ventStyle: 'Double Vent',
      },
      measurementHistory: [],
      alterations: [],
      isArchived: false,
      createdAt: nowIso,
      updatedAt: nowIso,
    };

    const newCustomer: Customer = {
      ...customerData,
      id: newCustId,
      familyMembers: customerData.familyMembers && customerData.familyMembers.length > 0
        ? customerData.familyMembers
        : [defaultSelfMember],
      totalOrdersCount: 0,
      totalSpentPKR: 0,
      createdAt: nowIso,
    };

    customers.unshift(newCustomer);
    this.setItem(STORAGE_KEYS.CUSTOMERS, customers);

    this.addAuditLog({
      userName: user.name,
      userRole: user.role,
      action: 'CUSTOMER_CREATED',
      details: `Registered client profile & family account: ${newCustomer.name} (City: ${newCustomer.city})`,
      entityType: 'CUSTOMER',
    });

    return newCustomer;
  }

  updateCustomer(
    customerId: string,
    updates: Partial<Customer>,
    user: UserAccount
  ): Customer | null {
    const customers = this.getItem<Customer[]>(STORAGE_KEYS.CUSTOMERS, INITIAL_CUSTOMERS);
    const index = customers.findIndex((c) => c.id === customerId);
    if (index === -1) return null;

    if (updates.city && typeof updates.city === 'string' && updates.city.trim()) {
      this.addCity(updates.city.trim());
    }

    const updatedCustomer: Customer = {
      ...customers[index],
      ...updates,
    };

    // If city or phone is updated, also update the 'Self' member if it exists
    if (updatedCustomer.familyMembers) {
      const selfMember = updatedCustomer.familyMembers.find((fm) => fm.relationship === 'Self');
      if (selfMember) {
        if (updates.city) selfMember.city = updates.city;
        if (updates.phone) selfMember.phone = updates.phone;
        if (updates.name) selfMember.name = updates.name;
        selfMember.updatedAt = new Date().toISOString();
      }
    }

    customers[index] = updatedCustomer;
    this.setItem(STORAGE_KEYS.CUSTOMERS, customers);

    this.addAuditLog({
      userName: user.name,
      userRole: user.role,
      action: 'CUSTOMER_UPDATED',
      details: `Updated family account profile: ${updatedCustomer.name} (City: ${updatedCustomer.city})`,
      entityType: 'CUSTOMER',
    });

    return updatedCustomer;
  }

  deleteCustomer(customerId: string, user: UserAccount): boolean {
    if (user.role !== 'ADMIN') {
      throw new Error('Access Denied: Only Admins can delete client accounts.');
    }
    const customers = this.getItem<Customer[]>(STORAGE_KEYS.CUSTOMERS, INITIAL_CUSTOMERS);
    const target = customers.find((c) => c.id === customerId);
    const filtered = customers.filter((c) => c.id !== customerId);
    this.setItem(STORAGE_KEYS.CUSTOMERS, filtered);

    if (target) {
      this.addAuditLog({
        userName: user.name,
        userRole: user.role,
        action: 'CUSTOMER_DELETED',
        details: `Deleted family account profile for ${target.name} (${target.city})`,
        entityType: 'CUSTOMER',
      });
    }
    return true;
  }

  updateCustomerMeasurements(customerId: string, measurements: Customer['measurements'], user: UserAccount): boolean {
    const customers = this.getItem<Customer[]>(STORAGE_KEYS.CUSTOMERS, INITIAL_CUSTOMERS);
    const index = customers.findIndex((c) => c.id === customerId);
    if (index === -1) return false;

    customers[index].measurements = measurements;

    // Also sync Self family member measurements if exists
    if (customers[index].familyMembers) {
      const selfMember = customers[index].familyMembers.find((fm) => fm.relationship === 'Self');
      if (selfMember && measurements) {
        selfMember.currentMeasurements = measurements;
        selfMember.updatedAt = new Date().toISOString();
      }
    }

    this.setItem(STORAGE_KEYS.CUSTOMERS, customers);

    this.addAuditLog({
      userName: user.name,
      userRole: user.role,
      action: 'MEASUREMENTS_UPDATED',
      details: `Updated bespoke tailor measurements for ${customers[index].name} (Chest: ${measurements?.chest}", Waist: ${measurements?.waist}")`,
      entityType: 'CUSTOMER',
    });

    return true;
  }

  // FAMILY MEMBER CRUD OPERATIONS
  addFamilyMember(
    customerId: string,
    memberData: Omit<FamilyMember, 'id' | 'customerId' | 'createdAt' | 'updatedAt' | 'isArchived' | 'measurementHistory' | 'alterations'>,
    user: UserAccount
  ): FamilyMember {
    const customers = this.getItem<Customer[]>(STORAGE_KEYS.CUSTOMERS, INITIAL_CUSTOMERS);
    const cIdx = customers.findIndex((c) => c.id === customerId);
    if (cIdx === -1) {
      throw new Error(`Customer with ID ${customerId} not found.`);
    }

    const memberId = `fm_${Date.now()}_${Math.floor(Math.random() * 1000)}`;
    const nowIso = new Date().toISOString();

    const newMember: FamilyMember = {
      ...memberData,
      id: memberId,
      customerId,
      isArchived: false,
      measurementHistory: [],
      alterations: [],
      createdAt: nowIso,
      updatedAt: nowIso,
    };

    if (!customers[cIdx].familyMembers) {
      customers[cIdx].familyMembers = [];
    }
    customers[cIdx].familyMembers.push(newMember);
    this.setItem(STORAGE_KEYS.CUSTOMERS, customers);

    this.addAuditLog({
      userName: user.name,
      userRole: user.role,
      action: 'FAMILY_MEMBER_ADDED',
      details: `Added family member ${newMember.name} (${newMember.relationship}) to family account ${customers[cIdx].name}`,
      entityType: 'CUSTOMER',
    });

    return newMember;
  }

  updateFamilyMember(
    customerId: string,
    memberId: string,
    updates: Partial<FamilyMember>,
    user: UserAccount
  ): FamilyMember | null {
    const customers = this.getItem<Customer[]>(STORAGE_KEYS.CUSTOMERS, INITIAL_CUSTOMERS);
    const cIdx = customers.findIndex((c) => c.id === customerId);
    if (cIdx === -1 || !customers[cIdx].familyMembers) return null;

    const mIdx = customers[cIdx].familyMembers.findIndex((m) => m.id === memberId);
    if (mIdx === -1) return null;

    const targetMember = customers[cIdx].familyMembers[mIdx];
    const updatedMember: FamilyMember = {
      ...targetMember,
      ...updates,
      updatedAt: new Date().toISOString(),
    };

    customers[cIdx].familyMembers[mIdx] = updatedMember;
    this.setItem(STORAGE_KEYS.CUSTOMERS, customers);

    this.addAuditLog({
      userName: user.name,
      userRole: user.role,
      action: 'FAMILY_MEMBER_UPDATED',
      details: `Updated family member profile ${updatedMember.name} (${updatedMember.relationship}) for family ${customers[cIdx].name}`,
      entityType: 'CUSTOMER',
    });

    return updatedMember;
  }

  archiveFamilyMember(customerId: string, memberId: string, user: UserAccount): boolean {
    const customers = this.getItem<Customer[]>(STORAGE_KEYS.CUSTOMERS, INITIAL_CUSTOMERS);
    const cIdx = customers.findIndex((c) => c.id === customerId);
    if (cIdx === -1 || !customers[cIdx].familyMembers) return false;

    const member = customers[cIdx].familyMembers.find((m) => m.id === memberId);
    if (!member) return false;

    // Soft archive: keep financial records intact
    member.isArchived = true;
    member.updatedAt = new Date().toISOString();
    this.setItem(STORAGE_KEYS.CUSTOMERS, customers);

    this.addAuditLog({
      userName: user.name,
      userRole: user.role,
      action: 'FAMILY_MEMBER_ARCHIVED',
      details: `Archived family member ${member.name} (${member.relationship}) under client ${customers[cIdx].name}. Financial and order histories preserved.`,
      entityType: 'CUSTOMER',
    });

    return true;
  }

  unarchiveFamilyMember(customerId: string, memberId: string, user: UserAccount): boolean {
    const customers = this.getItem<Customer[]>(STORAGE_KEYS.CUSTOMERS, INITIAL_CUSTOMERS);
    const cIdx = customers.findIndex((c) => c.id === customerId);
    if (cIdx === -1 || !customers[cIdx].familyMembers) return false;

    const member = customers[cIdx].familyMembers.find((m) => m.id === memberId);
    if (!member) return false;

    member.isArchived = false;
    member.updatedAt = new Date().toISOString();
    this.setItem(STORAGE_KEYS.CUSTOMERS, customers);

    this.addAuditLog({
      userName: user.name,
      userRole: user.role,
      action: 'FAMILY_MEMBER_RESTORED',
      details: `Restored archived family member ${member.name} (${member.relationship}) under client ${customers[cIdx].name}`,
      entityType: 'CUSTOMER',
    });

    return true;
  }

  addMemberMeasurementRevision(
    customerId: string,
    memberId: string,
    revisionData: {
      measurements: BespokeMeasurements;
      fitNotes?: string;
      customFields?: Record<string, string | number>;
    },
    user: UserAccount
  ): MeasurementRevision | null {
    const customers = this.getItem<Customer[]>(STORAGE_KEYS.CUSTOMERS, INITIAL_CUSTOMERS);
    const cIdx = customers.findIndex((c) => c.id === customerId);
    if (cIdx === -1 || !customers[cIdx].familyMembers) return null;

    const member = customers[cIdx].familyMembers.find((m) => m.id === memberId);
    if (!member) return null;

    const revision: MeasurementRevision = {
      id: `rev_${Date.now()}`,
      date: new Date().toISOString().slice(0, 10),
      measurements: { ...member.currentMeasurements },
      customFields: member.customFields ? { ...member.customFields } : undefined,
      fitNotes: revisionData.fitNotes || 'Routine fitting session revision',
      recordedBy: user.name,
    };

    if (!member.measurementHistory) {
      member.measurementHistory = [];
    }
    // Save snapshot of previous measurements to history
    member.measurementHistory.unshift(revision);

    // Apply new measurements as current
    member.currentMeasurements = { ...revisionData.measurements };
    if (revisionData.customFields) {
      member.customFields = { ...revisionData.customFields };
    }
    member.updatedAt = new Date().toISOString();

    // If this is the primary customer (Self), also sync customer.measurements
    if (member.relationship === 'Self') {
      customers[cIdx].measurements = { ...revisionData.measurements };
    }

    this.setItem(STORAGE_KEYS.CUSTOMERS, customers);

    this.addAuditLog({
      userName: user.name,
      userRole: user.role,
      action: 'MEMBER_MEASUREMENT_REVISED',
      details: `Recorded measurement revision for ${member.name} (${member.relationship}). Fit notes: "${revisionData.fitNotes || 'Standard'}"`,
      entityType: 'CUSTOMER',
    });

    return revision;
  }

  addMemberAlteration(
    customerId: string,
    memberId: string,
    alteration: Omit<AlterationRecord, 'id' | 'date'>,
    user: UserAccount
  ): AlterationRecord | null {
    const customers = this.getItem<Customer[]>(STORAGE_KEYS.CUSTOMERS, INITIAL_CUSTOMERS);
    const cIdx = customers.findIndex((c) => c.id === customerId);
    if (cIdx === -1 || !customers[cIdx].familyMembers) return null;

    const member = customers[cIdx].familyMembers.find((m) => m.id === memberId);
    if (!member) return null;

    const newAlteration: AlterationRecord = {
      ...alteration,
      id: `alt_${Date.now()}`,
      date: new Date().toISOString().slice(0, 10),
    };

    if (!member.alterations) {
      member.alterations = [];
    }
    member.alterations.unshift(newAlteration);
    member.updatedAt = new Date().toISOString();

    this.setItem(STORAGE_KEYS.CUSTOMERS, customers);

    this.addAuditLog({
      userName: user.name,
      userRole: user.role,
      action: 'ALTERATION_RECORDED',
      details: `Logged alteration for ${member.name}: ${alteration.garment} - ${alteration.alterationDetails} (${alteration.status})`,
      entityType: 'CUSTOMER',
    });

    return newAlteration;
  }

  getFamilyStats(customerId: string, userRole: UserRole) {
    const customers = this.getCustomers(userRole);
    const customer = customers.find((c) => c.id === customerId);
    const orders = this.getOrders(userRole).filter((o) => o.customerId === customerId);

    const members = customer?.familyMembers || [];
    const activeMembers = members.filter((m) => !m.isArchived);
    const archivedMembers = members.filter((m) => m.isArchived);

    const nonCancelledOrders = orders.filter((o) => o.status !== 'Cancelled');
    const pendingOrders = nonCancelledOrders.filter(
      (o) => o.status !== 'Delivered' && o.status !== 'Completed'
    );
    const completedOrders = nonCancelledOrders.filter(
      (o) => o.status === 'Delivered' || o.status === 'Completed'
    );

    const familyTotalSpentPKR = nonCancelledOrders.reduce((sum, o) => sum + o.grandTotalPKR, 0);
    const familyBalanceDuePKR = nonCancelledOrders.reduce((sum, o) => sum + o.balanceDuePKR, 0);
    const familyAdvancePaidPKR = nonCancelledOrders.reduce((sum, o) => sum + o.advancePaidPKR, 0);

    const upcomingDeliveries = pendingOrders
      .sort((a, b) => new Date(a.deliveryDate).getTime() - new Date(b.deliveryDate).getTime())
      .slice(0, 5);

    return {
      totalMembers: members.length,
      activeMembersCount: activeMembers.length,
      archivedMembersCount: archivedMembers.length,
      totalFamilyOrders: orders.length,
      pendingOrdersCount: pendingOrders.length,
      completedOrdersCount: completedOrders.length,
      familyTotalSpentPKR,
      familyBalanceDuePKR,
      familyAdvancePaidPKR,
      upcomingDeliveries,
    };
  }

  private updateCustomerSpend(customerId: string, amountPKR: number): void {
    const customers = this.getItem<Customer[]>(STORAGE_KEYS.CUSTOMERS, INITIAL_CUSTOMERS);
    const index = customers.findIndex((c) => c.id === customerId);
    if (index !== -1) {
      customers[index].totalOrdersCount += 1;
      customers[index].totalSpentPKR += amountPKR;
      this.setItem(STORAGE_KEYS.CUSTOMERS, customers);
    }
  }

  // PAYMENTS
  getPayments(): PaymentEntry[] {
    return this.getItem<PaymentEntry[]>(STORAGE_KEYS.PAYMENTS, INITIAL_PAYMENTS);
  }

  recordPayment(entryData: Omit<PaymentEntry, 'id'>, user: UserAccount): PaymentEntry {
    const payments = this.getPayments();
    const newPayment: PaymentEntry = {
      ...entryData,
      id: `pay_${Date.now()}`,
    };
    payments.unshift(newPayment);
    this.setItem(STORAGE_KEYS.PAYMENTS, payments);

    // Update order balance
    const orders = this.getItem<Order[]>(STORAGE_KEYS.ORDERS, INITIAL_ORDERS);
    const oIdx = orders.findIndex((o) => o.orderNumber === entryData.orderNumber);
    if (oIdx !== -1) {
      orders[oIdx].advancePaidPKR += entryData.amountPKR;
      orders[oIdx].balanceDuePKR = Math.max(0, orders[oIdx].grandTotalPKR - orders[oIdx].advancePaidPKR);
      if (orders[oIdx].balanceDuePKR === 0) {
        orders[oIdx].paymentStatus = 'Paid';
      } else {
        orders[oIdx].paymentStatus = 'Partial';
      }
      this.setItem(STORAGE_KEYS.ORDERS, orders);
    }

    this.addAuditLog({
      userName: user.name,
      userRole: user.role,
      action: 'PAYMENT_RECORDED',
      details: `Recorded PKR ${entryData.amountPKR.toLocaleString()} (${entryData.type}) for Order #${entryData.orderNumber} via ${entryData.method}`,
      entityType: 'PAYMENT',
    });

    return newPayment;
  }

  // EXPENSES WITH ROLE CHECK
  getExpenses(userRole: UserRole): ExpenseEntry[] {
    if (userRole === 'EMPLOYEE') {
      // Backend block
      throw new Error('403 Forbidden: Employees are not authorized to view business expenses.');
    }
    return this.getItem<ExpenseEntry[]>(STORAGE_KEYS.EXPENSES, INITIAL_EXPENSES);
  }

  recordExpense(expenseData: Omit<ExpenseEntry, 'id'>, user: UserAccount): ExpenseEntry {
    if (user.role !== 'ADMIN') {
      throw new Error('403 Forbidden: Only Admin can record company expenses.');
    }
    const expenses = this.getItem<ExpenseEntry[]>(STORAGE_KEYS.EXPENSES, INITIAL_EXPENSES);
    const newExpense: ExpenseEntry = {
      ...expenseData,
      id: `exp_${Date.now()}`,
    };
    expenses.unshift(newExpense);
    this.setItem(STORAGE_KEYS.EXPENSES, expenses);

    this.addAuditLog({
      userName: user.name,
      userRole: user.role,
      action: 'EXPENSE_RECORDED',
      details: `Recorded PKR ${newExpense.amountPKR.toLocaleString()} (${newExpense.category}) - ${newExpense.description}`,
      entityType: 'PAYMENT',
    });

    return newExpense;
  }

  // FINANCIAL & PROFIT REPORTS (ADMIN ONLY)
  getFinancialSummary(userRole: UserRole) {
    if (userRole === 'EMPLOYEE') {
      return {
        authorized: false,
        error: 'Employee account is restricted from viewing financial profit/loss records.',
      };
    }

    const orders = this.getItem<Order[]>(STORAGE_KEYS.ORDERS, INITIAL_ORDERS);
    const expenses = this.getItem<ExpenseEntry[]>(STORAGE_KEYS.EXPENSES, INITIAL_EXPENSES);
    const products = this.getProducts();

    const nonCancelledOrders = orders.filter((o) => o.status !== 'Cancelled');
    const grossRevenuePKR = nonCancelledOrders.reduce((sum, o) => sum + o.grandTotalPKR, 0);
    const totalCollectedPKR = nonCancelledOrders.reduce((sum, o) => sum + o.advancePaidPKR, 0);
    const pendingReceivablesPKR = nonCancelledOrders.reduce((sum, o) => sum + o.balanceDuePKR, 0);
    
    // Calculate Estimated Cost of Goods Sold (COGS)
    let totalCogsPKR = 0;
    for (const order of nonCancelledOrders) {
      for (const item of order.items) {
        const prod = products.find((p) => p.id === item.productId);
        const unitCost = prod ? prod.costPKR : item.unitPricePKR * 0.5;
        totalCogsPKR += unitCost * item.quantity;
      }
    }

    const totalOperatingExpensesPKR = expenses.reduce((sum, e) => sum + e.amountPKR, 0);
    const netProfitPKR = grossRevenuePKR - (totalCogsPKR + totalOperatingExpensesPKR);
    const profitMarginPercent = grossRevenuePKR > 0 ? ((netProfitPKR / grossRevenuePKR) * 100).toFixed(1) : '0';

    return {
      authorized: true,
      grossRevenuePKR,
      totalCollectedPKR,
      pendingReceivablesPKR,
      totalCogsPKR,
      totalOperatingExpensesPKR,
      netProfitPKR,
      profitMarginPercent,
      ordersCount: nonCancelledOrders.length,
      averageOrderValuePKR: nonCancelledOrders.length > 0 ? Math.round(grossRevenuePKR / nonCancelledOrders.length) : 0,
    };
  }

  // WHATSAPP CONVERSATIONS
  getWhatsAppConversations(userRole: UserRole): WhatsAppConversation[] {
    const convs = this.getItem<WhatsAppConversation[]>(STORAGE_KEYS.WHATSAPP, INITIAL_WHATSAPP);
    if (userRole === 'EMPLOYEE') {
      // Employees see triage view with masked phone numbers
      return convs.map((c) => ({
        ...c,
        customerPhone: maskPhoneNumber(c.customerPhone),
      }));
    }
    return convs;
  }

  sendWhatsAppMessage(conversationId: string, text: string, templateName?: string, user?: UserAccount): WhatsAppConversation | null {
    const convs = this.getItem<WhatsAppConversation[]>(STORAGE_KEYS.WHATSAPP, INITIAL_WHATSAPP);
    const index = convs.findIndex((c) => c.id === conversationId);
    if (index === -1) return null;

    const newMessage = {
      id: `msg_${Date.now()}`,
      conversationId,
      sender: 'business' as const,
      text,
      timestamp: new Date().toISOString().slice(11, 16),
      status: 'delivered' as const,
      templateName,
    };

    convs[index].messages.push(newMessage);
    convs[index].lastMessage = text;
    convs[index].lastTimestamp = 'Just now';
    this.setItem(STORAGE_KEYS.WHATSAPP, convs);

    if (user) {
      this.addAuditLog({
        userName: user.name,
        userRole: user.role,
        action: 'WHATSAPP_MESSAGE_SENT',
        details: `Sent message to client ${convs[index].customerName}: "${text.slice(0, 45)}..."`,
        entityType: 'CUSTOMER',
      });
    }

    return convs[index];
  }

  simulateCustomerReply(conversationId: string, replyText: string): WhatsAppConversation | null {
    const convs = this.getItem<WhatsAppConversation[]>(STORAGE_KEYS.WHATSAPP, INITIAL_WHATSAPP);
    const index = convs.findIndex((c) => c.id === conversationId);
    if (index === -1) return null;

    const reply = {
      id: `msg_cust_${Date.now()}`,
      conversationId,
      sender: 'customer' as const,
      text: replyText,
      timestamp: new Date().toISOString().slice(11, 16),
      status: 'read' as const,
    };

    convs[index].messages.push(reply);
    convs[index].lastMessage = replyText;
    convs[index].lastTimestamp = 'Just now';
    convs[index].unreadCount += 1;
    this.setItem(STORAGE_KEYS.WHATSAPP, convs);

    return convs[index];
  }

  // AUDIT LOGS
  getAuditLogs(): AuditLog[] {
    return this.getItem<AuditLog[]>(STORAGE_KEYS.AUDIT_LOGS, INITIAL_AUDIT_LOGS);
  }

  addAuditLog(entry: Omit<AuditLog, 'id' | 'timestamp'>): void {
    const logs = this.getItem<AuditLog[]>(STORAGE_KEYS.AUDIT_LOGS, INITIAL_AUDIT_LOGS);
    const newLog: AuditLog = {
      ...entry,
      id: `log_${Date.now()}`,
      timestamp: new Date().toISOString().slice(0, 16).replace('T', ' '),
    };
    logs.unshift(newLog);
    // Keep last 250 entries
    if (logs.length > 250) logs.pop();
    this.setItem(STORAGE_KEYS.AUDIT_LOGS, logs);
  }

  clearAuditLogs(user: UserAccount): void {
    if (user.role !== 'ADMIN') {
      throw new Error('Access Denied: Only Admins can clear audit logs.');
    }
    const purgedLog: AuditLog = {
      id: `log_${Date.now()}`,
      timestamp: new Date().toISOString().slice(0, 16).replace('T', ' '),
      userName: user.name,
      userRole: user.role,
      action: 'AUDIT_LOGS_PURGED',
      details: 'Historical audit logs were cleared by administrator.',
      entityType: 'AUTH',
    };
    this.setItem(STORAGE_KEYS.AUDIT_LOGS, [purgedLog]);
  }

  // NOTIFICATIONS
  getNotifications(): SystemNotification[] {
    return this.getItem<SystemNotification[]>(STORAGE_KEYS.NOTIFICATIONS, INITIAL_NOTIFICATIONS);
  }

  markNotificationRead(id: string): void {
    const notifs = this.getNotifications();
    const target = notifs.find((n) => n.id === id);
    if (target) {
      target.read = true;
      this.setItem(STORAGE_KEYS.NOTIFICATIONS, notifs);
    }
  }

  addNotification(notif: Omit<SystemNotification, 'id' | 'timestamp' | 'read'>): void {
    const notifs = this.getNotifications();
    const newNotif: SystemNotification = {
      ...notif,
      id: `notif_${Date.now()}`,
      timestamp: 'Just now',
      read: false,
    };
    notifs.unshift(newNotif);
    this.setItem(STORAGE_KEYS.NOTIFICATIONS, notifs);
  }

  // PRINTER & ATELIER PROFILE CONFIGURATION
  getPrinterConfig(): ThermalPrinterConfig {
    const cfg = this.getItem<ThermalPrinterConfig>(STORAGE_KEYS.PRINTER_CONFIG, INITIAL_PRINTER_CONFIG);
    // If stored configuration still contains the old demo name or demo website, clean it up
    if (cfg.businessName === 'ZUBAIR & SONS BESPOKE' || cfg.websiteUrl === 'https://zubairtailors.com') {
      const cleanCfg: ThermalPrinterConfig = {
        paperWidth: cfg.paperWidth || '80mm',
        businessName: '',
        tagline: '',
        address: '',
        city: '',
        phone: '',
        websiteUrl: '',
        ntnNumber: '',
        footerNote: '',
        printBarcode: cfg.printBarcode ?? true,
        cutPaperAfterPrint: cfg.cutPaperAfterPrint ?? true,
        autoSaveEnabled: cfg.autoSaveEnabled ?? true,
      };
      this.setItem(STORAGE_KEYS.PRINTER_CONFIG, cleanCfg);
      return cleanCfg;
    }
    return {
      ...INITIAL_PRINTER_CONFIG,
      ...cfg,
      autoSaveEnabled: cfg.autoSaveEnabled ?? true,
    };
  }

  updatePrinterConfig(config: ThermalPrinterConfig, user: UserAccount): void {
    if (user.role !== 'ADMIN') {
      throw new Error('Access Denied: Only Admins can modify settings.');
    }
    this.setItem(STORAGE_KEYS.PRINTER_CONFIG, config);
    this.addAuditLog({
      userName: user.name,
      userRole: user.role,
      action: 'SETTINGS_CONFIG_UPDATED',
      details: `Updated Atelier Settings: Auto-Save=${config.autoSaveEnabled ? 'ON' : 'OFF'}, Website=${config.websiteUrl || '(blank)'}`,
      entityType: 'SETTINGS',
    });
  }

  clearSettingsData(user: UserAccount): ThermalPrinterConfig {
    if (user.role !== 'ADMIN') {
      throw new Error('Access Denied: Only Admins can clear settings.');
    }
    const cleanCfg: ThermalPrinterConfig = {
      ...INITIAL_PRINTER_CONFIG,
      autoSaveEnabled: true,
    };
    this.setItem(STORAGE_KEYS.PRINTER_CONFIG, cleanCfg);
    this.addAuditLog({
      userName: user.name,
      userRole: user.role,
      action: 'SETTINGS_PURGED',
      details: 'Purged all demo data in settings. All fields set to clean empty values.',
      entityType: 'SETTINGS',
    });
    return cleanCfg;
  }

  // WHATSAPP CLOUD API CONFIG
  getWhatsAppConfig(): WhatsAppCloudApiConfig {
    const cfg = this.getItem<WhatsAppCloudApiConfig>(STORAGE_KEYS.WHATSAPP_CONFIG, INITIAL_WHATSAPP_CONFIG);
    // Sanitize old demo phone number ID if present
    if (cfg.phoneNumberId === '109841289410291') {
      const cleanCfg: WhatsAppCloudApiConfig = {
        ...INITIAL_WHATSAPP_CONFIG,
      };
      this.setItem(STORAGE_KEYS.WHATSAPP_CONFIG, cleanCfg);
      return cleanCfg;
    }
    return cfg;
  }

  updateWhatsAppConfig(cfg: WhatsAppCloudApiConfig, user: UserAccount): void {
    if (user.role !== 'ADMIN') {
      throw new Error('Access Denied: Only Admins can configure WhatsApp Cloud API credentials.');
    }
    this.setItem(STORAGE_KEYS.WHATSAPP_CONFIG, cfg);
    this.addAuditLog({
      userName: user.name,
      userRole: user.role,
      action: 'WHATSAPP_CONFIG_UPDATED',
      details: `Changed WhatsApp integration mode to ${cfg.mode}`,
      entityType: 'SETTINGS',
    });
  }

  // CATEGORIES
  getCategories(): string[] {
    return this.getItem<string[]>(STORAGE_KEYS.CATEGORIES, DEFAULT_CATEGORIES);
  }

  addCategory(name: string, user: UserAccount): string[] {
    const categories = this.getCategories();
    const cleanName = name.trim();
    if (!cleanName || categories.includes(cleanName)) return categories;

    categories.push(cleanName);
    this.setItem(STORAGE_KEYS.CATEGORIES, categories);

    this.addAuditLog({
      userName: user.name,
      userRole: user.role,
      action: 'CATEGORY_ADDED',
      details: `Created new suit category "${cleanName}"`,
      entityType: 'CATEGORY',
    });

    return categories;
  }

  renameCategory(oldName: string, newName: string, user: UserAccount): string[] {
    const categories = this.getCategories();
    const cleanNew = newName.trim();
    const idx = categories.indexOf(oldName);
    if (idx === -1 || !cleanNew) return categories;

    categories[idx] = cleanNew;
    this.setItem(STORAGE_KEYS.CATEGORIES, categories);

    // Also update all products that used this category
    const products = this.getProducts();
    let updatedCount = 0;
    products.forEach((p) => {
      if (p.category === oldName) {
        p.category = cleanNew;
        updatedCount++;
      }
    });
    if (updatedCount > 0) {
      this.setItem(STORAGE_KEYS.PRODUCTS, products);
    }

    this.addAuditLog({
      userName: user.name,
      userRole: user.role,
      action: 'CATEGORY_RENAMED',
      details: `Renamed category "${oldName}" to "${cleanNew}" (${updatedCount} products updated)`,
      entityType: 'CATEGORY',
    });

    return categories;
  }

  deleteCategory(name: string, user: UserAccount): string[] {
    if (user.role !== 'ADMIN') {
      throw new Error('Access Denied: Only Admins can remove categories.');
    }
    const categories = this.getCategories();
    const filtered = categories.filter((c) => c !== name);
    this.setItem(STORAGE_KEYS.CATEGORIES, filtered);

    this.addAuditLog({
      userName: user.name,
      userRole: user.role,
      action: 'CATEGORY_DELETED',
      details: `Removed category "${name}" from catalog`,
      entityType: 'CATEGORY',
    });

    return filtered;
  }

  // THEME (Dark / Light)
  getTheme(): 'dark' | 'light' {
    return this.getItem<'dark' | 'light'>(STORAGE_KEYS.THEME, 'dark');
  }

  setTheme(theme: 'dark' | 'light'): void {
    this.setItem(STORAGE_KEYS.THEME, theme);
  }

  // DIRECT WHATSAPP LINKING
  addWhatsAppContact(
    customerId: string,
    customerName: string,
    phone: string,
    initialMessage?: string,
    user?: UserAccount
  ): WhatsAppConversation {
    const convs = this.getItem<WhatsAppConversation[]>(STORAGE_KEYS.WHATSAPP, INITIAL_WHATSAPP);
    const existingIdx = convs.findIndex(
      (c) => c.customerPhone.replace(/\D/g, '') === phone.replace(/\D/g, '')
    );

    const timeStr = 'Just now';
    const initText = initialMessage || `Assalam-o-Alaikum ${customerName}! Welcome to our bespoke atelier. How can we assist you with your suit fitting or order today?`;

    if (existingIdx !== -1) {
      convs[existingIdx].messages.push({
        id: `msg_${Date.now()}`,
        conversationId: convs[existingIdx].id,
        sender: 'business',
        text: initText,
        timestamp: new Date().toISOString().slice(11, 16),
        status: 'delivered',
      });
      convs[existingIdx].lastMessage = initText;
      convs[existingIdx].lastTimestamp = timeStr;
      this.setItem(STORAGE_KEYS.WHATSAPP, convs);
      return convs[existingIdx];
    }

    const newConv: WhatsAppConversation = {
      id: `conv_${Date.now()}`,
      customerId,
      customerName,
      customerPhone: phone,
      unreadCount: 0,
      lastMessage: initText,
      lastTimestamp: timeStr,
      messages: [
        {
          id: `msg_${Date.now()}`,
          conversationId: `conv_${Date.now()}`,
          sender: 'business',
          text: initText,
          timestamp: new Date().toISOString().slice(11, 16),
          status: 'delivered',
        },
      ],
    };

    convs.unshift(newConv);
    this.setItem(STORAGE_KEYS.WHATSAPP, convs);

    if (user) {
      this.addAuditLog({
        userName: user.name,
        userRole: user.role,
        action: 'WHATSAPP_CONTACT_LINKED',
        details: `Linked client WhatsApp number ${phone} for ${customerName}`,
        entityType: 'CUSTOMER',
      });
    }

    return newConv;
  }

  // FULL BACKUP EXPORT & RESTORE
  exportFullBackup(): string {
    const backup = {
      version: '2.4.0',
      timestamp: new Date().toISOString(),
      products: this.getProducts(),
      orders: this.getItem<Order[]>(STORAGE_KEYS.ORDERS, INITIAL_ORDERS),
      customers: this.getItem<Customer[]>(STORAGE_KEYS.CUSTOMERS, INITIAL_CUSTOMERS),
      categories: this.getCategories(),
      payments: this.getPayments(),
      expenses: this.getItem<ExpenseEntry[]>(STORAGE_KEYS.EXPENSES, INITIAL_EXPENSES),
      whatsapp: this.getItem<WhatsAppConversation[]>(STORAGE_KEYS.WHATSAPP, INITIAL_WHATSAPP),
      auditLogs: this.getAuditLogs(),
      printerConfig: this.getPrinterConfig(),
    };
    return JSON.stringify(backup, null, 2);
  }

  importFullBackup(jsonString: string, user: UserAccount): boolean {
    if (user.role !== 'ADMIN') {
      throw new Error('Access Denied: Only Admins can import database backups.');
    }
    try {
      const data = JSON.parse(jsonString);
      if (Array.isArray(data.products)) this.setItem(STORAGE_KEYS.PRODUCTS, data.products);
      if (Array.isArray(data.orders)) this.setItem(STORAGE_KEYS.ORDERS, data.orders);
      if (Array.isArray(data.customers)) this.setItem(STORAGE_KEYS.CUSTOMERS, data.customers);
      if (Array.isArray(data.categories)) this.setItem(STORAGE_KEYS.CATEGORIES, data.categories);
      if (Array.isArray(data.payments)) this.setItem(STORAGE_KEYS.PAYMENTS, data.payments);
      if (Array.isArray(data.expenses)) this.setItem(STORAGE_KEYS.EXPENSES, data.expenses);
      if (Array.isArray(data.whatsapp)) this.setItem(STORAGE_KEYS.WHATSAPP, data.whatsapp);
      if (Array.isArray(data.auditLogs)) this.setItem(STORAGE_KEYS.AUDIT_LOGS, data.auditLogs);
      if (data.printerConfig) this.setItem(STORAGE_KEYS.PRINTER_CONFIG, data.printerConfig);

      this.addAuditLog({
        userName: user.name,
        userRole: user.role,
        action: 'DATABASE_RESTORED',
        details: `Restored full database backup created at ${data.timestamp || 'unknown'}`,
        entityType: 'BACKUP',
      });

      return true;
    } catch (err: any) {
      throw new Error(`Failed to import backup: ${err.message}`);
    }
  }

  // CSV EXPORT & IMPORT FOR PRODUCTS
  exportProductsCSV(): string {
    const products = this.getProducts();
    const headers = ['Code', 'Title', 'Category', 'Fabric', 'Color', 'PricePKR', 'CostPKR', 'StockQty', 'MinStockAlert', 'Sizes', 'Description'];
    const rows = products.map((p) => [
      `"${p.code.replace(/"/g, '""')}"`,
      `"${p.title.replace(/"/g, '""')}"`,
      `"${p.category.replace(/"/g, '""')}"`,
      `"${p.fabric.replace(/"/g, '""')}"`,
      `"${p.color.replace(/"/g, '""')}"`,
      p.pricePKR,
      p.costPKR,
      p.stockQty,
      p.minStockAlert,
      `"${p.sizesAvailable.join(', ').replace(/"/g, '""')}"`,
      `"${(p.description || '').replace(/"/g, '""')}"`,
    ]);

    return [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
  }

  importProductsCSV(csvText: string, user: UserAccount): { success: number; errors: string[] } {
    const lines = csvText.trim().split(/\r?\n/);
    if (lines.length < 2) {
      return { success: 0, errors: ['CSV file is empty or missing headers.'] };
    }

    const currentProducts = this.getProducts();
    const categories = this.getCategories();
    let successCount = 0;
    const errors: string[] = [];

    for (let i = 1; i < lines.length; i++) {
      const line = lines[i].trim();
      if (!line) continue;

      // Simple CSV split handling quotes
      const regex = /(?:,|\n|^)("(?:(?:"")*[^"]*)*"|[^",\n]*|(?:\n|$))/g;
      const matches: string[] = [];
      let match;
      while ((match = regex.exec(line)) !== null && matches.length < 11) {
        let val = match[1] || '';
        if (val.startsWith('"') && val.endsWith('"')) {
          val = val.slice(1, -1).replace(/""/g, '"');
        }
        matches.push(val.trim());
      }

      const [code, title, category, fabric, color, priceStr, costStr, stockStr, minAlertStr, sizesStr, description] = matches;

      if (!title || !priceStr) {
        errors.push(`Row ${i + 1}: Missing required title or price.`);
        continue;
      }

      const cleanCode = code || `ZS-${Date.now().toString().slice(-4)}`;
      const cleanCat = category || 'Three-Piece Suit';
      if (!categories.includes(cleanCat)) {
        categories.push(cleanCat);
      }

      const existingIdx = currentProducts.findIndex((p) => p.code.toLowerCase() === cleanCode.toLowerCase());
      const newProd: Product = {
        id: existingIdx !== -1 ? currentProducts[existingIdx].id : `prod_${Date.now()}_${i}`,
        code: cleanCode,
        title,
        category: cleanCat,
        fabric: fabric || 'Super 150s Merino Wool',
        color: color || 'Navy Blue',
        pricePKR: Number(priceStr) || 50000,
        costPKR: Number(costStr) || 25000,
        stockQty: Number(stockStr) || 5,
        minStockAlert: Number(minAlertStr) || 2,
        sizesAvailable: sizesStr ? sizesStr.split(',').map((s) => s.trim()).filter(Boolean) : ['38R', '40R', '42R'],
        imageUrl: '/src/assets/images/suit_royal_navy_3piece_1792162981461.jpg',
        description: description || 'Imported via CSV batch catalog',
      };

      if (existingIdx !== -1) {
        currentProducts[existingIdx] = newProd;
      } else {
        currentProducts.push(newProd);
      }
      successCount++;
    }

    this.setItem(STORAGE_KEYS.PRODUCTS, currentProducts);
    this.setItem(STORAGE_KEYS.CATEGORIES, categories);

    this.addAuditLog({
      userName: user.name,
      userRole: user.role,
      action: 'CSV_PRODUCTS_IMPORTED',
      details: `Imported ${successCount} products from CSV file`,
      entityType: 'PRODUCT',
    });

    return { success: successCount, errors };
  }

  // RESET DEMO DATA
  resetDemoData(): void {
    localStorage.removeItem(STORAGE_KEYS.PRODUCTS);
    localStorage.removeItem(STORAGE_KEYS.ORDERS);
    localStorage.removeItem(STORAGE_KEYS.CUSTOMERS);
    localStorage.removeItem(STORAGE_KEYS.PAYMENTS);
    localStorage.removeItem(STORAGE_KEYS.EXPENSES);
    localStorage.removeItem(STORAGE_KEYS.WHATSAPP);
    localStorage.removeItem(STORAGE_KEYS.AUDIT_LOGS);
    localStorage.removeItem(STORAGE_KEYS.NOTIFICATIONS);
    localStorage.removeItem(STORAGE_KEYS.PRINTER_CONFIG);
    localStorage.removeItem(STORAGE_KEYS.WHATSAPP_CONFIG);
    localStorage.removeItem(STORAGE_KEYS.CURRENT_USER);
    localStorage.removeItem(STORAGE_KEYS.CATEGORIES);
    localStorage.removeItem(STORAGE_KEYS.THEME);

    // Re-initialize with pristine defaults (all demo records empty)
    this.setItem(STORAGE_KEYS.PRODUCTS, INITIAL_PRODUCTS);
    this.setItem(STORAGE_KEYS.ORDERS, INITIAL_ORDERS);
    this.setItem(STORAGE_KEYS.CUSTOMERS, INITIAL_CUSTOMERS);
    this.setItem(STORAGE_KEYS.PAYMENTS, INITIAL_PAYMENTS);
    this.setItem(STORAGE_KEYS.EXPENSES, INITIAL_EXPENSES);
    this.setItem(STORAGE_KEYS.WHATSAPP, INITIAL_WHATSAPP);
    this.setItem(STORAGE_KEYS.AUDIT_LOGS, INITIAL_AUDIT_LOGS);
    this.setItem(STORAGE_KEYS.NOTIFICATIONS, INITIAL_NOTIFICATIONS);
    this.setItem(STORAGE_KEYS.PRINTER_CONFIG, INITIAL_PRINTER_CONFIG);
    this.setItem(STORAGE_KEYS.WHATSAPP_CONFIG, INITIAL_WHATSAPP_CONFIG);
    this.setItem(STORAGE_KEYS.CURRENT_USER, ADMIN_USER);
    this.setItem(STORAGE_KEYS.CATEGORIES, DEFAULT_CATEGORIES);
    this.setItem(STORAGE_KEYS.THEME, 'dark');
  }

  // PURGE ALL DATA (START TOTALLY FRESH)
  clearAllData(user: UserAccount): void {
    if (user.role !== 'ADMIN') {
      throw new Error('Access Denied: Only Admins can clear database records.');
    }
    this.setItem(STORAGE_KEYS.PRODUCTS, []);
    this.setItem(STORAGE_KEYS.ORDERS, []);
    this.setItem(STORAGE_KEYS.CUSTOMERS, []);
    this.setItem(STORAGE_KEYS.PAYMENTS, []);
    this.setItem(STORAGE_KEYS.EXPENSES, []);
    this.setItem(STORAGE_KEYS.WHATSAPP, []);

    this.addAuditLog({
      userName: user.name,
      userRole: user.role,
      action: 'ALL_DATA_CLEARED',
      details: 'All products, customers, orders, expenses, and WhatsApp messages purged. Clean slate initialized.',
      entityType: 'BACKUP',
    });
  }

  // PURGE ALL DEMO DATA INCLUDING SETTINGS
  removeAllDemoData(user: UserAccount): ThermalPrinterConfig {
    if (user.role !== 'ADMIN') {
      throw new Error('Access Denied: Only Admins can remove all demo data.');
    }
    this.clearAllData(user);
    const cleanConfig = this.clearSettingsData(user);
    return cleanConfig;
  }

  // LOAD SAMPLE DEMO DATA (OPTIONAL FOR TESTING)
  loadSampleData(user: UserAccount): void {
    if (user.role !== 'ADMIN') {
      throw new Error('Access Denied: Only Admins can load sample data.');
    }
    this.setItem(STORAGE_KEYS.PRODUCTS, SAMPLE_PRODUCTS);
    this.setItem(STORAGE_KEYS.ORDERS, SAMPLE_ORDERS);
    this.setItem(STORAGE_KEYS.CUSTOMERS, SAMPLE_CUSTOMERS);
    this.setItem(STORAGE_KEYS.PAYMENTS, SAMPLE_PAYMENTS);
    this.setItem(STORAGE_KEYS.EXPENSES, SAMPLE_EXPENSES);
    this.setItem(STORAGE_KEYS.WHATSAPP, SAMPLE_WHATSAPP);

    this.addAuditLog({
      userName: user.name,
      userRole: user.role,
      action: 'SAMPLE_DATA_LOADED',
      details: 'Loaded showroom sample products, family clients, and orders for testing.',
      entityType: 'BACKUP',
    });
  }

  // UPDATE BUSINESS WEBSITE
  updateWebsiteUrl(websiteUrl: string, user: UserAccount): ThermalPrinterConfig {
    const config = this.getPrinterConfig();
    const cleanUrl = websiteUrl.trim();
    config.websiteUrl = cleanUrl;
    this.setItem(STORAGE_KEYS.PRINTER_CONFIG, config);

    this.addAuditLog({
      userName: user.name,
      userRole: user.role,
      action: 'WEBSITE_URL_UPDATED',
      details: `Updated atelier official website URL to: ${cleanUrl || '(none)'}`,
      entityType: 'SETTINGS',
    });

    return config;
  }
}

export const db = new DemoDatabaseService();
