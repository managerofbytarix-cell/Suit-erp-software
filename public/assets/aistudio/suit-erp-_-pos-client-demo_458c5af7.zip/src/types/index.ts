/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type UserRole = 'ADMIN' | 'EMPLOYEE';
export type AppTheme = 'dark' | 'light';

export interface UserPermissions {
  canViewProfits: boolean;
  canViewCustomerPhone: boolean;
  canViewCustomerAddress: boolean;
  canViewPrivateWhatsApp: boolean;
  canManageSettings: boolean;
  canDeleteRecords: boolean;
  canExportData: boolean;
  canViewFinancialTotals: boolean;
  canEditMeasurements: boolean;
  canApplyDiscounts: boolean;
  allowedViews?: string[];
}

export interface UserAccount {
  id: string;
  username: string;
  password?: string;
  name: string;
  email: string;
  role: UserRole;
  title: string;
  avatarUrl?: string;
  createdAt?: string;
  permissions: UserPermissions;
}

export type SuitCategory = string;

export interface Product {
  id: string;
  code: string; // e.g. ZS-701
  title: string;
  category: string;
  fabric: string; // e.g. Super 150s Wool, Italian Cashmere, Jamawar
  color: string;
  pricePKR: number;
  costPKR: number; // Cost of goods (hidden from employee)
  stockQty: number;
  minStockAlert: number;
  sizesAvailable: string[];
  imageUrl: string;
  description: string;
  isCustomTailoredOnly?: boolean;
}

export interface BespokeMeasurements {
  chest: number; // inches
  waist: number;
  hip: number;
  shoulder: number;
  sleeve: number;
  jacketLength: number;
  collar: number;
  trouserWaist: number;
  trouserLength: number;
  inseam: number;
  thigh: number;
  lapelStyle: 'Peak Lapel' | 'Notch Lapel' | 'Shawl Collar' | 'Mandarin Collar' | string;
  ventStyle: 'Double Vent' | 'Single Vent' | 'No Vent' | string;
  customNotes?: string;
}

export interface MeasurementRevision {
  id: string;
  date: string;
  measurements: BespokeMeasurements;
  customFields?: Record<string, string | number>;
  fitNotes?: string;
  recordedBy: string;
}

export interface AlterationRecord {
  id: string;
  orderNumber?: string;
  date: string;
  garment: string;
  alterationDetails: string;
  status: 'Received' | 'In Tailoring' | 'Ready for Fitting' | 'Completed';
  masterTailor: string;
  costPKR?: number;
}

export interface FamilyMember {
  id: string;
  customerId: string; // References primary customer
  name: string;
  relationship: 'Self' | 'Father' | 'Brother' | 'Son' | 'Uncle' | 'Cousin' | 'Nephew' | 'Groom' | string;
  photoUrl?: string;
  phone?: string;
  city?: string;
  notes?: string;
  preferences?: string; // fabric / fit preferences
  currentMeasurements: BespokeMeasurements;
  customFields?: Record<string, string | number>;
  measurementHistory: MeasurementRevision[];
  alterations?: AlterationRecord[];
  isArchived?: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface Customer {
  id: string;
  name: string;
  phone: string; // Restricted for employee
  email: string;
  city: 'Lahore' | 'Karachi' | 'Islamabad' | 'Faisalabad' | 'Rawalpindi' | 'Peshawar' | 'Multan' | string;
  address: string; // Restricted for employee
  measurements?: BespokeMeasurements;
  customFields?: Record<string, string | number>;
  notes?: string;
  linkedWhatsAppNumber?: string;
  familyMembers?: FamilyMember[];
  totalOrdersCount: number;
  totalSpentPKR: number;
  createdAt: string;
}

export type OrderStatus = 
  | 'Draft'
  | 'Fabric Cut'
  | 'In Tailoring'
  | 'Fitting Scheduled'
  | 'Ready for Dispatch'
  | 'Dispatched'
  | 'Delivered'
  | 'Completed'
  | 'Cancelled';

export type PaymentStatus = 'Unpaid' | 'Partial' | 'Paid';

export interface OrderItem {
  productId: string;
  productCode: string;
  title: string;
  fabric: string;
  color: string;
  sizeOrTailoring: string; // e.g. "40R" or "Bespoke Custom"
  quantity: number;
  unitPricePKR: number;
  totalPricePKR: number;
}

export interface Order {
  id: string;
  orderNumber: string; // e.g. ZS-2026-1042
  customerId: string;
  customerName: string;
  customerPhone: string; // Will be masked if retrieved as Employee
  customerCity: string;
  customerAddress: string; // Will be masked if retrieved as Employee
  familyMemberId?: string;
  familyMemberName?: string;
  familyMemberRelationship?: string;
  items: OrderItem[];
  subtotalPKR: number;
  tailoringFeePKR: number;
  discountPKR: number;
  shippingFeePKR: number;
  grandTotalPKR: number;
  advancePaidPKR: number;
  balanceDuePKR: number;
  paymentStatus: PaymentStatus;
  paymentMethod: 'Cash on Delivery' | 'Bank Transfer / Raast' | 'POS Card' | 'Cash at Atelier' | string;
  status: OrderStatus;
  isRushOrder: boolean;
  eventDate?: string;
  deliveryDate: string;
  assignedToEmployeeId?: string;
  measurementsSnapshot?: BespokeMeasurements;
  customFieldsSnapshot?: Record<string, string | number>;
  specialInstructions?: string;
  createdAt: string;
  updatedAt: string;
}

export interface PaymentEntry {
  id: string;
  orderNumber: string;
  customerName: string;
  amountPKR: number;
  type: 'Advance Deposit' | 'Balance Settlement' | 'Full Payment' | 'Refund' | string;
  method: 'Raast / Online Bank' | 'Cash on Delivery' | 'POS Debit/Credit Card' | 'Cash' | string;
  referenceNumber: string;
  date: string;
  recordedBy: string;
}

export interface ExpenseEntry {
  id: string;
  category: 'Tailor Master Wages' | 'Fabric & Lining Procurement' | 'Packaging & Suit Covers' | 'Showroom Rent & Utilities' | 'Logistics & Courier' | 'Marketing' | string;
  description: string;
  amountPKR: number;
  date: string;
  paymentMethod: string;
  vendorName: string;
  receiptNumber: string;
  recordedBy: string;
}

export interface WhatsAppMessage {
  id: string;
  conversationId: string;
  sender: 'customer' | 'business';
  text: string;
  timestamp: string;
  status: 'sent' | 'delivered' | 'read';
  templateName?: string;
}

export interface WhatsAppConversation {
  id: string;
  customerId: string;
  customerName: string;
  customerPhone: string;
  unreadCount: number;
  lastMessage: string;
  lastTimestamp: string;
  orderNumberRef?: string;
  messages: WhatsAppMessage[];
}

export interface AuditLog {
  id: string;
  timestamp: string;
  userName: string;
  userRole: UserRole;
  action: string;
  details: string;
  entityType: 'ORDER' | 'PRODUCT' | 'PAYMENT' | 'CUSTOMER' | 'AUTH' | 'SETTINGS' | 'CATEGORY' | 'BACKUP' | 'AI_AGENT';
}

export interface SystemNotification {
  id: string;
  title: string;
  message: string;
  timestamp: string;
  type: 'order' | 'inventory' | 'payment' | 'fitting' | 'ai';
  read: boolean;
  linkTab?: string;
  targetId?: string;
}

export interface ThermalPrinterConfig {
  paperWidth: '58mm' | '80mm';
  businessName: string;
  tagline: string;
  address: string;
  city: string;
  phone: string;
  websiteUrl?: string;
  ntnNumber: string;
  footerNote: string;
  printBarcode: boolean;
  cutPaperAfterPrint: boolean;
  autoSaveEnabled?: boolean;
  autoSaveDelayMs?: number;
}

export interface WhatsAppCloudApiConfig {
  mode: 'DEMO' | 'LIVE';
  phoneNumberId: string;
  businessAccountId: string;
  permanentAccessToken: string;
  webhookVerifyToken: string;
  isConnected: boolean;
  lastWebhookPing?: string;
}

export interface AIAssistantMessage {
  id: string;
  sender: 'user' | 'assistant';
  text: string;
  timestamp: string;
  actionType?: 'CREATE_ORDER' | 'GENERATE_INVOICE' | 'UPDATE_STOCK' | 'ADD_CATEGORY' | 'INSIGHT' | 'NONE';
  actionPayload?: any;
  executed?: boolean;
}

export interface FullBackupData {
  version: string;
  timestamp: string;
  products: Product[];
  orders: Order[];
  customers: Customer[];
  categories: string[];
  payments: PaymentEntry[];
  expenses: ExpenseEntry[];
  whatsapp: WhatsAppConversation[];
  auditLogs: AuditLog[];
  printerConfig: ThermalPrinterConfig;
}
