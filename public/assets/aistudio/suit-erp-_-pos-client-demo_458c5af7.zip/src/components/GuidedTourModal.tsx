/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { 
  CheckCircle2, 
  ChevronRight, 
  ChevronLeft, 
  X, 
  Layers, 
  Scissors, 
  Receipt, 
  MessageSquare, 
  ShieldCheck, 
  TrendingUp, 
  CreditCard,
  Printer
} from 'lucide-react';

interface GuidedTourModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentStep: number;
  onStepChange: (step: number) => void;
  onNavigateTab: (tab: string) => void;
}

export const TOUR_STEPS = [
  {
    step: 1,
    title: 'Executive Dashboard & Atelier KPIs',
    tab: 'dashboard',
    icon: Layers,
    description: 'Real-time overview of tailoring production, gross PKR revenue, pending receivables (COD & bank balance), and low fabric inventory alerts.',
    highlights: [
      'Gross Revenue & Collected Cash Flow in PKR',
      'Production pipeline: Fabric Cut to Delivered',
      'Recent high-value bespoke orders with live status badges',
      'Quick action launcher for suits and test thermal slips',
    ],
  },
  {
    step: 2,
    title: 'Products, Fabrics & Stock Control',
    tab: 'products',
    icon: Scissors,
    description: 'Complete bespoke suit catalog with fabric provenance (Super 150s Merino Wool, Pure Raw Silk, Jamawar, Velvet Prince Coats), colors, and live stock tracking.',
    highlights: [
      'High-fidelity studio photography of bespoke Pakistani menswear',
      'Add & Edit Product modals with price vs cost (COGS) specifications',
      'Instant stock adjustments with reason tracking in the audit log',
      'Automatic low-stock threshold alerts (<= 3 garments)',
    ],
  },
  {
    step: 3,
    title: 'Create Bespoke Suit Order & Measurements',
    tab: 'orders',
    icon: Receipt,
    description: 'End-to-end bespoke order entry: client selection, tailor measurement card (chest, waist, shoulder, inseam, lapel styling), and wedding delivery scheduling.',
    highlights: [
      'Order stages: Draft → Fabric Cut → In Tailoring → Fitting → Ready → Delivered',
      'Multi-garment cart with custom tailoring options & rush wedding flag',
      'Automatic inventory reduction upon order creation',
      'Advance deposit vs outstanding balance calculation in PKR',
    ],
  },
  {
    step: 4,
    title: 'Payments, Raast Settlement & Courier COD',
    tab: 'finance',
    icon: CreditCard,
    description: 'Financial ledger tracking customer advance deposits, Raast online transfers, HBL/Meezan POS card swipes, and Cash on Delivery (COD) tracking.',
    highlights: [
      'Direct order balance settlement recording',
      'Operational expenses ledger: Master tailor wages, fabrics, LESCO electricity',
      'Automatic calculation of pending receivables',
      'Exportable financial audit trail',
    ],
  },
  {
    step: 5,
    title: 'System Audit Log & Security Trail',
    tab: 'audit',
    icon: ShieldCheck,
    description: 'Immutable chronological register of all atelier transactions, customer modifications, order dispatches, and administrative configurations.',
    highlights: [
      'Chronological activity register: Orders, customers, stock shifts, settings',
      'Role-based security: Salesperson actions logged; sensitive phone numbers hidden',
      'Filterable by entity type (Order, Customer, Product, Payment, Settings, Auth)',
      '1-click export to CSV & JSON for regulatory and bookkeeping audits',
    ],
  },
  {
    step: 6,
    title: '58mm & 80mm POS Thermal Receipt Engine',
    tab: 'thermal',
    icon: Printer,
    description: 'Real thermal receipt previews engineered to standard 58mm (narrow 2-inch) and 80mm (wide 3-inch) roll widths with high-contrast formatting.',
    highlights: [
      '4 Functional Print Actions: Receipt, Tax Invoice, Packing Slip & Alignment Test',
      'Direct browser printing with tuned @media print thermal styles',
      'Client privacy protection: phone & street address masking for staff',
      'Urdu/English atelier branding, NTN number and QR verification tag',
    ],
  },
  {
    step: 7,
    title: 'Store Website & Role-Based Access Control',
    tab: 'settings',
    icon: ShieldCheck,
    description: 'Configure your official business website URL, store branding, hardware printer roll width, and role-based privacy isolation.',
    highlights: [
      'Store Website URL: Add your site link to display on thermal receipts, invoices & header',
      'Data Management: Purge all demo records to start 100% clean, or load showroom samples',
      'Employee Data Shield: Customer telephone numbers & street addresses masked for staff',
      'Financial P&L reports blocked for staff with 403 Forbidden simulated shield',
    ],
  },
  {
    step: 8,
    title: 'P&L Financials & Production Readiness',
    tab: 'production',
    icon: TrendingUp,
    description: 'Executive profit and loss summary, Cost of Goods Sold (COGS), automated system validation checks, and clear production transition roadmap.',
    highlights: [
      'Net Profit & Margin % after tailoring wages and fabric procurement',
      'Automated environment validation runner for client IT sign-off',
      'Database migration scripts & Meta Cloud API webhook specifications',
      'Comprehensive Atelier Onboarding & Master Tailor user manual',
    ],
  },
];

export const GuidedTourModal: React.FC<GuidedTourModalProps> = ({
  isOpen,
  onClose,
  currentStep,
  onStepChange,
  onNavigateTab,
}) => {
  if (!isOpen) return null;

  const stepInfo = TOUR_STEPS[currentStep - 1] || TOUR_STEPS[0];
  const StepIcon = stepInfo.icon;

  const handleNext = () => {
    if (currentStep < TOUR_STEPS.length) {
      const nextStep = currentStep + 1;
      onStepChange(nextStep);
      onNavigateTab(TOUR_STEPS[nextStep - 1].tab);
    } else {
      onClose();
    }
  };

  const handlePrev = () => {
    if (currentStep > 1) {
      const prevStep = currentStep - 1;
      onStepChange(prevStep);
      onNavigateTab(TOUR_STEPS[prevStep - 1].tab);
    }
  };

  const handleSelectStep = (sNum: number) => {
    onStepChange(sNum);
    onNavigateTab(TOUR_STEPS[sNum - 1].tab);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
      <div className="relative w-full max-w-2xl bg-neutral-900 border border-neutral-800 rounded-xl shadow-2xl overflow-hidden flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-neutral-800 bg-neutral-950/60">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400">
              <StepIcon className="w-4 h-4" />
            </div>
            <div>
              <div className="flex items-center gap-2 text-xs text-amber-400/90 font-medium">
                <span>Client Demo Presentation Walkthrough</span>
                <span aria-hidden="true">·</span>
                <span>Stage {currentStep} of {TOUR_STEPS.length}</span>
              </div>
              <h2 className="text-base font-semibold text-neutral-100">{stepInfo.title}</h2>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-neutral-400 hover:text-neutral-200 p-1.5 rounded-lg hover:bg-neutral-800 transition-colors"
            title="Close presentation walkthrough"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Stage step indicators */}
        <div className="flex items-center justify-between px-6 py-2.5 bg-neutral-950 border-b border-neutral-800/80 overflow-x-auto gap-1">
          {TOUR_STEPS.map((s) => {
            const isActive = s.step === currentStep;
            const isCompleted = s.step < currentStep;
            return (
              <button
                key={s.step}
                onClick={() => handleSelectStep(s.step)}
                className={`flex items-center gap-1.5 px-2.5 py-1 text-xs rounded-md whitespace-nowrap transition-colors ${
                  isActive
                    ? 'bg-amber-500 text-neutral-950 font-semibold shadow-sm'
                    : isCompleted
                    ? 'text-neutral-300 hover:text-white bg-neutral-800/50'
                    : 'text-neutral-500 hover:text-neutral-400'
                }`}
              >
                <span>{s.step}.</span>
                <span className="hidden sm:inline">{s.title.split(' ')[0]}</span>
              </button>
            );
          })}
        </div>

        {/* Content */}
        <div className="p-6 space-y-5 text-sm">
          <p className="text-neutral-300 leading-relaxed text-base">
            {stepInfo.description}
          </p>

          <div className="bg-neutral-950/80 border border-neutral-800/90 rounded-lg p-4 space-y-3">
            <div className="text-xs font-semibold text-neutral-400 uppercase tracking-wider">
              Key Capabilities In This Stage
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              {stepInfo.highlights.map((h, idx) => (
                <div key={idx} className="flex items-start gap-2 text-xs text-neutral-200">
                  <CheckCircle2 className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                  <span>{h}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="flex items-center justify-between text-xs text-neutral-400 bg-neutral-800/30 p-3 rounded-lg border border-neutral-800">
            <span>Currently previewing tab:</span>
            <span className="font-mono text-amber-400 bg-neutral-900 px-2 py-0.5 rounded border border-neutral-700">
              /{stepInfo.tab}
            </span>
          </div>
        </div>

        {/* Footer actions */}
        <div className="flex items-center justify-between px-6 py-4 border-t border-neutral-800 bg-neutral-950/80">
          <button
            onClick={handlePrev}
            disabled={currentStep === 1}
            className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg transition-colors ${
              currentStep === 1
                ? 'text-neutral-600 cursor-not-allowed'
                : 'text-neutral-300 hover:text-white bg-neutral-800 hover:bg-neutral-700'
            }`}
          >
            <ChevronLeft className="w-4 h-4" />
            Previous
          </button>

          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              className="px-3 py-1.5 text-xs text-neutral-400 hover:text-neutral-200 transition-colors"
            >
              Exit Tour
            </button>
            <button
              onClick={handleNext}
              className="flex items-center gap-1.5 px-4 py-1.5 text-xs font-semibold text-neutral-950 bg-amber-400 hover:bg-amber-300 rounded-lg transition-colors shadow-sm"
            >
              {currentStep === TOUR_STEPS.length ? 'Finish Walkthrough' : 'Next Stage'}
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
