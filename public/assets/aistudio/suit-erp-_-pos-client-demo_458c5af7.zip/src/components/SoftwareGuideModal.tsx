/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  BookOpen,
  X,
  Search,
  Globe,
  Scissors,
  Users,
  ShoppingBag,
  Printer,
  MessageSquare,
  CreditCard,
  ShieldCheck,
  Bot,
  ChevronRight,
  ExternalLink,
  Sparkles,
  CheckCircle2,
  HelpCircle,
  FileText,
  Languages
} from 'lucide-react';
import { ThermalPrinterConfig } from '../types/index.ts';

interface SoftwareGuideModalProps {
  isOpen: boolean;
  onClose: () => void;
  printerConfig?: ThermalPrinterConfig;
  onNavigateTab?: (tab: string) => void;
  isDarkMode?: boolean;
}

interface GuideModule {
  id: string;
  icon: any;
  titleEn: string;
  titleUr: string;
  badge: string;
  tabTarget?: string;
  summaryEn: string;
  summaryUr: string;
  stepsEn: { title: string; desc: string; tip?: string }[];
  stepsUr: { title: string; desc: string; tip?: string }[];
}

export const SoftwareGuideModal: React.FC<SoftwareGuideModalProps> = ({
  isOpen,
  onClose,
  printerConfig,
  onNavigateTab,
  isDarkMode = true,
}) => {
  const [language, setLanguage] = useState<'both' | 'en' | 'ur'>('both');
  const [activeModuleId, setActiveModuleId] = useState<string>('website');
  const [searchQuery, setSearchQuery] = useState('');

  if (!isOpen) return null;

  const modules: GuideModule[] = [
    {
      id: 'website',
      icon: Globe,
      titleEn: '1. Store Identity & Adding Your Website',
      titleUr: '۱. دکان کی معلومات اور ویب سائٹ شامل کرنا',
      badge: 'Store Setup',
      tabTarget: 'settings',
      summaryEn: 'Configure your bespoke business name, official website URL, phone number, and physical store address.',
      summaryUr: 'Apni tailoring dukan ka naam, official website ka link, telephone aur pata darj karein jo raseed aur invoice par print hoga.',
      stepsEn: [
        {
          title: 'Navigate to Settings',
          desc: 'Click on "Atelier Settings & RBAC" in the sidebar navigation or click the Settings icon.',
          tip: 'Only users with the ADMIN role can modify store configuration.'
        },
        {
          title: 'Open the "Store Profile & Website" Tab',
          desc: 'Locate the "Official Website URL" field and enter your website address (e.g. https://www.yourdomain.com).',
          tip: 'You can test your website immediately by clicking the "Test / Visit Website" button next to the input field.'
        },
        {
          title: 'Save Changes',
          desc: 'Click "Save Business Profile & Website". The software will automatically display your website link in the top navigation bar, thermal printed receipts, sales tax invoices, and WhatsApp messages.',
        }
      ],
      stepsUr: [
        {
          title: 'Settings tab par jayein',
          desc: 'Left side menu se "Atelier Settings & RBAC" par click karein.',
          tip: 'Yad rahe sirf ADMIN user dukan ki settings tabdeel kar sakta hai.'
        },
        {
          title: 'Website ka URL darj karein',
          desc: '"Store Profile & Website" section mein "Official Website URL" ke dabay mein apni website ka link likhein (maslan: https://www.yourtailors.com).',
          tip: 'Link ke sath "Test / Visit Website" button dabakar aap check kar sakte hain ke link theek khul raha hai.'
        },
        {
          title: 'Save karein',
          desc: '"Save Business Profile & Website" button dabayein. Aapki website ka link top bar, thermal raseed aur invoices par khud ba khud shamil ho jayega.'
        }
      ]
    },
    {
      id: 'products',
      icon: Scissors,
      titleEn: '2. Adding Suits, Fabrics & Category Management',
      titleUr: '۲. سوٹ، کپڑے اور کیٹیگریز شامل کرنا',
      badge: 'Catalogue & Stock',
      tabTarget: 'products',
      summaryEn: 'Add ready-made or bespoke suits with fabric types, high-res photos, stock quantities, and prices in PKR.',
      summaryUr: 'Naye suits, unka kapra, pictures, stock ki tadaad aur keemat (PKR) software mein shamil karein.',
      stepsEn: [
        {
          title: 'Open Products & Fabrics',
          desc: 'Go to the "Products & Fabrics" tab from the sidebar. You will see your suit catalogue.',
        },
        {
          title: 'Click "+ Add Bespoke Product"',
          desc: 'Fill in Product Code (e.g. ZS-701), Title (e.g. Italian Wool 3-Piece), Category, Fabric specification, Sale Price (PKR), Cost Price (COGS), and initial stock quantity.',
          tip: 'Cost Price is strictly hidden from Employees to protect business profit margins.'
        },
        {
          title: 'Add Product Photo & Sizes',
          desc: 'Enter an image URL or choose pre-stocked studio photos. Select standard sizes (38R, 40R, 42R) or mark as "Bespoke Custom".',
        },
        {
          title: 'Managing Categories & CSV Import/Export',
          desc: 'Use the Category pill manager to add or rename categories (e.g. Sherwani, Tuxedo, Prince Coat). Use "Export CSV" and "Import CSV" for bulk updating.',
        }
      ],
      stepsUr: [
        {
          title: 'Products tab open karein',
          desc: 'Menu se "Products & Fabrics" par click karein jahan aapka sara suit stock show hota hai.',
        },
        {
          title: '"+ Add Bespoke Product" dabayein',
          desc: 'Soot ka Code (maslan ZS-801), Title, Category, Kapray ki quality (Wool, Silk wagera), Sale Price aur Stock quantity darj karein.',
          tip: 'Cost Price sirf Admin ko nazar aayegi, sales employee ko cost ya profit nahi dikhta.'
        },
        {
          title: 'Picture aur Size chunein',
          desc: 'Soot ki tasveer ka link dalein aur sizes (38R, 40R, Bespoke Custom) select karein.',
        },
        {
          title: 'CSV Import / Export aur Categories',
          desc: 'Aap categories ko rename ya add kar sakte hain aur CSV file ke zariye bulk suits import ya export kar sakte hain.'
        }
      ]
    },
    {
      id: 'customers',
      icon: Users,
      titleEn: '3. Customer Family Management & Dedicated Profiles',
      titleUr: '۳. کسٹمر اور فیملی ممبرز کا نظام',
      badge: 'Family Directory',
      tabTarget: 'customers',
      summaryEn: 'Manage primary customers with unlimited linked family members (Father, Son, Brother, Uncle, etc.) and individual profiles.',
      summaryUr: 'Aik sarbarah customer ke andar unke puray khandan (Beta, Bhai, Walid wagera) ke alag profiles aur naap banana.',
      stepsEn: [
        {
          title: 'Add Primary Customer',
          desc: 'Under "Client Measurement Cards", click "+ New Customer". Enter their Name, Phone number, City, and baseline measurements.',
        },
        {
          title: 'Open Customer Family Dashboard',
          desc: 'Click on any customer in the list to open their dedicated Family Dashboard. You will see family KPI cards (Total Members, Family Orders, Outstanding Balance).',
        },
        {
          title: 'Add Unlimited Family Members',
          desc: 'Click "+ Add Family Member". Select relationship (Father, Son, Brother, Uncle, Cousin, etc.) and enter their specific measurements and style preferences.',
          tip: 'Each family member has separate clothing measurements, fit revision history, and alteration logs.'
        },
        {
          title: 'Custom Tailoring Fields',
          desc: 'If a garment requires special measurements (like Sherwani Length, Armhole Depth, or Kamiz Daman), click "+ Add Custom Measurement" to record any bespoke specification.',
        }
      ],
      stepsUr: [
        {
          title: 'Naya Main Customer banayein',
          desc: '"Client Measurement Cards" tab mein upar daayein "+ New Customer" dabayein aur naam aur phone number likhein.',
        },
        {
          title: 'Family Dashboard open karein',
          desc: 'Customer ke card par click karein. Unka dedicated Family Dashboard khul jayega jahan total khandan ke orders aur baqaya balance nazar aayega.',
        },
        {
          title: 'Family Member (Beta, Bhai wagera) shamil karein',
          desc: '"+ Add Family Member" dabayein. Rishta chunein (Son, Brother, Father wagera) aur unka alag naap darj karein.',
          tip: 'Har fard ka naap aur purani alterations alag record hoti hain.'
        },
        {
          title: 'Khas Naap (Custom Fields)',
          desc: 'Agar Sherwani ki lambai ya Kamiz daman ka khas naap lena ho toh "+ Add Custom Measurement" se naya field shamil karein.'
        }
      ]
    },
    {
      id: 'orders',
      icon: ShoppingBag,
      titleEn: '4. Creating Family Orders & Frozen Measurements',
      titleUr: '۴. فیملی ممبر کے لیے سوٹ کا آرڈر بک کرنا',
      badge: 'Bespoke Orders',
      tabTarget: 'orders',
      summaryEn: 'Book bespoke suits for a specific family member. The exact measurements are frozen into the order so future edits never corrupt past orders.',
      summaryUr: 'Khandan ke kisi khas fard ke liye order book karein. Naap freeze ho jata hai taake aainda badalne se purana order kharab na ho.',
      stepsEn: [
        {
          title: 'Launch Order from Customer or Member Card',
          desc: 'In the Customer Dashboard, click "New Order for [Member Name]" on their card, or go to the Orders tab and click "+ Create Bespoke Order".',
        },
        {
          title: 'Member Measurements Auto-Load',
          desc: 'When the member is selected, their current bespoke measurements are automatically populated into the order.',
        },
        {
          title: 'Historical Measurement Freeze',
          desc: 'The software captures an immutable measurement snapshot inside the order. Even if the customer gains or loses weight next year, the original order record remains 100% accurate.',
        },
        {
          title: 'Advance Payment & Delivery Date',
          desc: 'Enter tailoring fees, discount, advance deposit paid (PKR), and the delivery/fitting deadline.',
        }
      ],
      stepsUr: [
        {
          title: 'Member ke card se order shuru karein',
          desc: 'Customer dashboard mein member ke samnay "New Order for [Name]" par click karein.',
        },
        {
          title: 'Naap khud ba khud load hoga',
          desc: 'Order form mein us member ke mehfooz shuda naap automatically aa jayenge.',
        },
        {
          title: 'Naap hamesha ke liye Freeze ho jata hai',
          desc: 'Order bante waqt naap ka snapshot mehfooz ho jata hai, taake aainda saal agar naap tabdeel bhi ho toh purana order na badlay.',
        },
        {
          title: 'Advance raqam aur tareekh',
          desc: 'Customer se wasool shuda advance payment darj karein aur delivery ki tareekh muqarrar karein.'
        }
      ]
    },
    {
      id: 'thermal',
      icon: Printer,
      titleEn: '5. POS Thermal Printing & 58mm / 80mm Receipts',
      titleUr: '۵. تھرمل پرنٹر سے رسید اور انوائس پرنٹ کرنا',
      badge: 'Hardware POS',
      tabTarget: 'thermal',
      summaryEn: 'Print high-contrast monochrome receipts and tax invoices on standard 58mm (2-inch) or 80mm (3-inch) ESC/POS thermal paper rolls.',
      summaryUr: 'POS thermal printer se 58mm ya 80mm roll par fori raseed aur invoice print karein.',
      stepsEn: [
        {
          title: 'Open Thermal Receipt Station',
          desc: 'Go to the "Thermal Receipt Station" tab, or click "Print Thermal Receipt" directly from any order row.',
        },
        {
          title: 'Choose Paper Width',
          desc: 'Toggle between 58mm (narrow 32-column roll) or 80mm (standard 48-column roll) depending on your hardware printer.',
        },
        {
          title: 'Automatic Website & Store Branding',
          desc: 'The receipt automatically displays your store name, official website URL, phone number, NTN tax ID, and customer balance due.',
        },
        {
          title: 'Execute Print',
          desc: 'Click "Print Customer Receipt" to launch standard ESC/POS browser print. Barcodes and auto-paper cut commands are supported.',
        }
      ],
      stepsUr: [
        {
          title: 'Thermal Station open karein',
          desc: '"Thermal Receipt Station" tab mein jayein ya kisi bhi order ke aagay "Print Slip" dabayein.',
        },
        {
          title: '58mm ya 80mm paper roll select karein',
          desc: 'Apne printer ke mutabiq 58mm (chota roll) ya 80mm (bara roll) ka intekhab karein.',
        },
        {
          title: 'Website aur raseed footer',
          desc: 'Raseed par aapki dukan ka naam, website ka pata, telephone number aur baqaya raqam print hogi.',
        },
        {
          title: 'Print dabayein',
          desc: '"Print Customer Receipt" dabate hi printer se raseed nikal aayegi.'
        }
      ]
    },
    {
      id: 'audit',
      icon: ShieldCheck,
      titleEn: '6. System Audit Log & Staff Role Privacy Isolation',
      titleUr: '۶. سسٹم آڈٹ لاگ اور اسٹاف پرائیویسی کنٹرول',
      badge: 'Security & Audit',
      tabTarget: 'audit',
      summaryEn: 'Immutable chronological audit register of all shop transactions and role-based staff view protection.',
      summaryUr: 'Tamam transactions ka mehfooz audit log aur sales staff se customer number chupana.',
      stepsEn: [
        {
          title: 'Chronological Audit Trail',
          desc: 'Every order created, customer registered, city added, stock changed, and payment settled is permanently logged with timestamp and user operator.',
        },
        {
          title: 'Salesperson View Restriction',
          desc: 'Sales associates only see the options they use (Orders, Products, Customers, Thermal Receipts). Admin sections like Audit Logs, Financials, and Settings are hidden.',
        },
        {
          title: 'Client Phone Privacy Guard',
          desc: 'Salespersons can only view client names and measurements for fittings. Direct customer phone numbers are shielded and hidden to protect atelier client exclusivity.',
        }
      ],
      stepsUr: [
        {
          title: 'Mehfooz Tareekhi Record (Audit Log)',
          desc: 'Har order, naya customer, payment aur stock ka tabadla waqt aur user ke naam ke sath mehfooz hota hai.',
        },
        {
          title: 'Salesperson ke liye mehdood view',
          desc: 'Sales staff sirf wo options dekh sakta hai jo unke kaam ke hain. Financials, Settings aur Audit Log un se chupaye gaye hain.',
        },
        {
          title: 'Customer phone number chhupana',
          desc: 'Salesperson sirf customer ka naam aur pemaish dekh sakta hai, phone number unko nazar nahi aayega.',
        }
      ]
    },
    {
      id: 'finance',
      icon: CreditCard,
      titleEn: '7. Financial Ledger, Expenses & Role Isolation (Admin vs Employee)',
      titleUr: '۷. حساب کتاب، اخراجات اور ملازم کی سیکیورٹی',
      badge: 'Finance & RBAC',
      tabTarget: 'finance',
      summaryEn: 'Track revenue, advance payments, master tailor wages, and protect business privacy with strict Employee role isolation.',
      summaryUr: 'Karobar ki aamdani, darziyon ki ujrat, aur employee se nafa aur phone number chupanay ka tareeqa.',
      stepsEn: [
        {
          title: 'Record Payments & Expenses',
          desc: 'Record customer balance settlements via Raast / Bank transfer, card swipe, or Cash. Log operational costs like Tailor Master Wages and Fabric Procurement.',
        },
        {
          title: 'Role-Based Access Control (RBAC)',
          desc: 'Switch between Admin and Employee roles via the top header badge to test security boundaries.',
        },
        {
          title: 'Employee Data Shield',
          desc: 'Employees can create orders and update tailoring stages, but CANNOT see client telephone numbers (masked as +92 300 •••-••10), client street addresses, Cost Prices, or profit margins.',
        }
      ],
      stepsUr: [
        {
          title: 'Raqam ki wasooli aur akhrajat',
          desc: 'Raast bank transfer ya cash advance darj karein. Master tailors ki ujrat aur kapray ki khareedari record karein.',
        },
        {
          title: 'Admin aur Employee ka farq',
          desc: 'Top bar se aap Admin aur Employee role switch karke dekh sakte hain.',
        },
        {
          title: 'Employee se data chupana',
          desc: 'Employee naya order bana sakta hai magar wo customer ka mukammal phone number, ghar ka pata, aur aapka profit margin hargiz nahi dekh sakta.'
        }
      ]
    },
    {
      id: 'ai',
      icon: Bot,
      titleEn: '8. Using the AI Assistant for Atelier Management',
      titleUr: '۸. اے آئی اسسٹنٹ سے مدد اور آرڈرز بنوانا',
      badge: 'AI Atelier',
      summaryEn: 'Ask the built-in AI assistant to draft bespoke orders, check fabric stock, generate invoices, or ask any question about the software.',
      summaryUr: 'AI assistant se baat karke naya order banwayein, stock maloom karein ya software chalane ka tareeqa poochein.',
      stepsEn: [
        {
          title: 'Open AI Manager',
          desc: 'Click the "AI Manager" button in the top navigation bar or sidebar to open the Sartorial AI panel.',
        },
        {
          title: 'Command AI in Plain English or Roman Urdu',
          desc: 'Type commands like "Create a rush order for Tariq Bajwa with 40,000 advance", "Check low stock suits", or "How do I add a family member?".',
        },
        {
          title: 'Instant Execution',
          desc: 'The AI analyzes your shop catalog, verifies parameters, and offers one-click execution with full safety review before recording to database.',
        }
      ],
      stepsUr: [
        {
          title: 'AI Manager open karein',
          desc: 'Top bar mein "AI Manager" button dabayein.',
        },
        {
          title: 'Urdu ya English mein baat karein',
          desc: 'Likhien: "Tariq Bajwa ke betay ke liye naya suit order banao" ya "Kaunse suits ka stock kam hai?", AI foran hisab karke batayega.',
        },
        {
          title: 'Fori amal daramad',
          desc: 'AI aapke hukum par raseed banata hai aur aapke confirm karne par database mein save kar deta hai.'
        }
      ]
    }
  ];

  // Search filter
  const filteredModules = modules.filter(m => {
    const q = searchQuery.toLowerCase();
    return (
      m.titleEn.toLowerCase().includes(q) ||
      m.titleUr.toLowerCase().includes(q) ||
      m.summaryEn.toLowerCase().includes(q) ||
      m.summaryUr.toLowerCase().includes(q) ||
      m.badge.toLowerCase().includes(q)
    );
  });

  const activeModule = modules.find(m => m.id === activeModuleId) || modules[0];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/80 backdrop-blur-sm animate-fadeIn">
      <div className={`w-full max-w-5xl max-h-[90vh] flex flex-col rounded-2xl shadow-2xl border overflow-hidden transition-colors ${
        isDarkMode
          ? 'bg-neutral-900 border-neutral-800 text-neutral-100'
          : 'bg-white border-stone-300 text-stone-900'
      }`}>
        {/* Modal Top Header */}
        <div className={`flex items-center justify-between px-6 py-4 border-b ${
          isDarkMode ? 'bg-neutral-950/80 border-neutral-800' : 'bg-stone-100/80 border-stone-200'
        }`}>
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-amber-500/20 border border-amber-500/40 text-amber-500 flex items-center justify-center">
              <BookOpen className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base font-bold tracking-tight font-serif-display">
                  Software User Manual &amp; Step-by-Step Guide
                </h2>
                <span className="px-2 py-0.5 text-[10px] rounded-full bg-amber-500/15 text-amber-500 font-semibold border border-amber-500/30">
                  Rahnumai (رہنمائی)
                </span>
              </div>
              <p className="text-xs text-neutral-400 mt-0.5">
                Complete walkthrough for store setup, website configuration, bespoke suits, family management, and POS.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            {/* Language Switcher */}
            <div className={`flex items-center gap-1 p-1 rounded-lg border text-xs ${
              isDarkMode ? 'bg-neutral-900 border-neutral-800' : 'bg-white border-stone-200'
            }`}>
              <Languages className="w-3.5 h-3.5 text-neutral-400 ml-1.5" />
              <button
                onClick={() => setLanguage('both')}
                className={`px-2 py-1 rounded text-xs font-medium transition-colors ${
                  language === 'both'
                    ? 'bg-amber-400 text-neutral-950 font-bold'
                    : 'text-neutral-400 hover:text-white'
                }`}
              >
                Both
              </button>
              <button
                onClick={() => setLanguage('en')}
                className={`px-2 py-1 rounded text-xs font-medium transition-colors ${
                  language === 'en'
                    ? 'bg-amber-400 text-neutral-950 font-bold'
                    : 'text-neutral-400 hover:text-white'
                }`}
              >
                English
              </button>
              <button
                onClick={() => setLanguage('ur')}
                className={`px-2 py-1 rounded text-xs font-medium transition-colors ${
                  language === 'ur'
                    ? 'bg-amber-400 text-neutral-950 font-bold'
                    : 'text-neutral-400 hover:text-white'
                }`}
              >
                Roman Urdu
              </button>
            </div>

            <button
              onClick={onClose}
              className={`p-1.5 rounded-lg border transition-colors ${
                isDarkMode
                  ? 'border-neutral-800 text-neutral-400 hover:text-white hover:bg-neutral-800'
                  : 'border-stone-200 text-stone-500 hover:text-stone-900 hover:bg-stone-200'
              }`}
              title="Close Guide"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Search Bar */}
        <div className={`px-6 py-2.5 border-b flex items-center gap-3 ${
          isDarkMode ? 'bg-neutral-950/40 border-neutral-800' : 'bg-stone-50 border-stone-200'
        }`}>
          <Search className="w-4 h-4 text-neutral-400 shrink-0" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search topics (e.g. website, family member, measurements, thermal, Urdu, stock)..."
            className="w-full bg-transparent text-xs text-neutral-200 placeholder-neutral-500 focus:outline-none"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="text-xs text-neutral-400 hover:text-white"
            >
              Clear
            </button>
          )}
        </div>

        {/* Modal Body: Left Modules List + Right Detail View */}
        <div className="flex-1 flex flex-col md:flex-row min-h-0 overflow-hidden">
          {/* Module Selector Sidebar */}
          <div className={`w-full md:w-72 border-r overflow-y-auto p-3 space-y-1.5 shrink-0 ${
            isDarkMode ? 'border-neutral-800 bg-neutral-950/30' : 'border-stone-200 bg-stone-50/60'
          }`}>
            <div className="text-[11px] font-semibold text-neutral-400 px-2 py-1 uppercase tracking-wider">
              Guide Topics ({filteredModules.length})
            </div>

            {filteredModules.map((mod) => {
              const Icon = mod.icon;
              const isActive = activeModuleId === mod.id;
              return (
                <button
                  key={mod.id}
                  onClick={() => setActiveModuleId(mod.id)}
                  className={`w-full text-left p-2.5 rounded-xl border transition-all flex items-start gap-2.5 ${
                    isActive
                      ? isDarkMode
                        ? 'bg-amber-500/15 border-amber-500/40 text-amber-300 shadow-sm'
                        : 'bg-amber-50 border-amber-300 text-amber-900 shadow-sm'
                      : isDarkMode
                      ? 'border-transparent text-neutral-300 hover:bg-neutral-800/60 hover:text-white'
                      : 'border-transparent text-stone-700 hover:bg-stone-200/60 hover:text-stone-900'
                  }`}
                >
                  <div className={`w-7 h-7 rounded-lg flex items-center justify-center shrink-0 mt-0.5 ${
                    isActive
                      ? 'bg-amber-400 text-neutral-950'
                      : isDarkMode
                      ? 'bg-neutral-800 text-neutral-400'
                      : 'bg-stone-200 text-stone-600'
                  }`}>
                    <Icon className="w-3.5 h-3.5" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="text-xs font-semibold truncate">
                      {language === 'ur' ? mod.titleUr : mod.titleEn}
                    </div>
                    <div className="text-[10px] text-neutral-400 truncate mt-0.5">
                      {mod.badge}
                    </div>
                  </div>
                  <ChevronRight className={`w-3.5 h-3.5 mt-1 shrink-0 ${
                    isActive ? 'text-amber-500' : 'text-neutral-600'
                  }`} />
                </button>
              );
            })}
          </div>

          {/* Module Content View */}
          <div className="flex-1 overflow-y-auto p-6 space-y-6">
            {/* Active Topic Banner */}
            <div className={`p-5 rounded-2xl border ${
              isDarkMode ? 'bg-neutral-950 border-neutral-800' : 'bg-stone-50 border-stone-200'
            }`}>
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-amber-500 text-neutral-950 flex items-center justify-center font-bold shadow-md">
                    <activeModule.icon className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="text-[10px] font-mono uppercase tracking-wider text-amber-500 font-bold block">
                      {activeModule.badge}
                    </span>
                    <h3 className="text-lg font-bold text-white font-serif-display">
                      {activeModule.titleEn}
                    </h3>
                    <p className="text-xs text-amber-400/90 font-medium">
                      {activeModule.titleUr}
                    </p>
                  </div>
                </div>

                {activeModule.tabTarget && onNavigateTab && (
                  <button
                    onClick={() => {
                      onNavigateTab(activeModule.tabTarget!);
                      onClose();
                    }}
                    className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg bg-amber-400 hover:bg-amber-300 text-neutral-950 shadow-sm transition-colors self-start sm:self-center"
                  >
                    <span>Open {activeModule.tabTarget.toUpperCase()} Tab</span>
                    <ExternalLink className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>

              {/* Summaries */}
              <div className="mt-4 pt-3 border-t border-neutral-800/80 space-y-2 text-xs">
                {(language === 'both' || language === 'en') && (
                  <p className="text-neutral-300 leading-relaxed">
                    <strong className="text-white">Overview:</strong> {activeModule.summaryEn}
                  </p>
                )}
                {(language === 'both' || language === 'ur') && (
                  <p className="text-amber-200/90 leading-relaxed font-sans">
                    <strong className="text-amber-400">Khulasa (خلاصہ):</strong> {activeModule.summaryUr}
                  </p>
                )}
              </div>
            </div>

            {/* Step-by-Step Instructions */}
            <div className="space-y-4">
              <h4 className="text-xs font-bold text-neutral-400 uppercase tracking-wider flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                <span>Step-by-Step Instructions / Amal Daramad</span>
              </h4>

              <div className="space-y-4">
                {activeModule.stepsEn.map((stepEn, idx) => {
                  const stepUr = activeModule.stepsUr[idx];
                  return (
                    <div
                      key={idx}
                      className={`p-4 rounded-xl border transition-colors ${
                        isDarkMode
                          ? 'bg-neutral-900/60 border-neutral-800 hover:border-neutral-700'
                          : 'bg-white border-stone-200 shadow-xs'
                      }`}
                    >
                      <div className="flex items-start gap-3">
                        <div className="w-6 h-6 rounded-full bg-amber-500/20 text-amber-500 border border-amber-500/40 flex items-center justify-center text-xs font-bold shrink-0 mt-0.5">
                          {idx + 1}
                        </div>

                        <div className="flex-1 space-y-2">
                          {(language === 'both' || language === 'en') && (
                            <div>
                              <div className="text-xs font-bold text-white">
                                {stepEn.title}
                              </div>
                              <p className="text-xs text-neutral-300 mt-1 leading-relaxed">
                                {stepEn.desc}
                              </p>
                              {stepEn.tip && (
                                <div className="mt-2 p-2 rounded-lg bg-neutral-950/70 border border-neutral-800 text-[11px] text-amber-400 flex items-center gap-1.5">
                                  <Sparkles className="w-3.5 h-3.5 shrink-0" />
                                  <span>{stepEn.tip}</span>
                                </div>
                              )}
                            </div>
                          )}

                          {(language === 'both' || language === 'ur') && stepUr && (
                            <div className={`${language === 'both' ? 'pt-2 border-t border-neutral-800/60' : ''}`}>
                              <div className="text-xs font-bold text-amber-400">
                                {stepUr.title}
                              </div>
                              <p className="text-xs text-amber-100/90 mt-1 leading-relaxed">
                                {stepUr.desc}
                              </p>
                              {stepUr.tip && (
                                <div className="mt-2 p-2 rounded-lg bg-amber-950/30 border border-amber-800/40 text-[11px] text-amber-300 flex items-center gap-1.5">
                                  <Sparkles className="w-3.5 h-3.5 shrink-0" />
                                  <span>{stepUr.tip}</span>
                                </div>
                              )}
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Active Website Preview Helper Box (If on Website tab) */}
            {activeModule.id === 'website' && (
              <div className="p-4 rounded-xl bg-gradient-to-r from-blue-950/40 to-neutral-950 border border-blue-900/40 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Globe className="w-4 h-4 text-blue-400" />
                    <span className="text-xs font-bold text-white">Your Currently Configured Website</span>
                  </div>
                  {printerConfig?.websiteUrl ? (
                    <a
                      href={printerConfig.websiteUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-xs font-medium text-amber-400 hover:text-amber-300 flex items-center gap-1"
                    >
                      <span>Visit Site</span>
                      <ExternalLink className="w-3 h-3" />
                    </a>
                  ) : (
                    <span className="text-xs text-neutral-500 font-mono">Not set yet</span>
                  )}
                </div>

                <div className="flex items-center gap-2 bg-neutral-950 p-2.5 rounded-lg border border-neutral-800 font-mono text-xs text-blue-300 overflow-x-auto">
                  <span>{printerConfig?.websiteUrl || 'https://www.yourtailors.com (Set this in Settings)'}</span>
                </div>

                <p className="text-[11px] text-neutral-400 leading-relaxed">
                  Go to <strong>Settings &rarr; Store Profile &amp; Website</strong> to change this URL anytime. When set, it appears automatically on all receipts, PDF invoices, and WhatsApp order messages.
                </p>
              </div>
            )}
          </div>
        </div>

        {/* Modal Footer */}
        <div className={`px-6 py-3 border-t flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs ${
          isDarkMode ? 'bg-neutral-950/80 border-neutral-800' : 'bg-stone-100 border-stone-200'
        }`}>
          <div className="flex items-center gap-2 text-neutral-400">
            <HelpCircle className="w-4 h-4 text-amber-500" />
            <span>Need more live help? Click <strong>AI Manager</strong> at any time to ask in natural English or Roman Urdu!</span>
          </div>

          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-white font-medium transition-colors"
          >
            Close Guide
          </button>
        </div>
      </div>
    </div>
  );
};
