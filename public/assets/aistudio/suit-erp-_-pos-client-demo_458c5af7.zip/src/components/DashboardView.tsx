/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import {
  TrendingUp,
  ShoppingBag,
  Clock,
  AlertTriangle,
  ArrowUpRight,
  Scissors,
  Printer,
  MessageSquare,
  Plus,
  CheckCircle2,
  Calendar,
  Sparkles
} from 'lucide-react';
import { Order, Product, UserAccount } from '../types/index.ts';

interface DashboardViewProps {
  orders: Order[];
  products: Product[];
  currentUser: UserAccount;
  onNavigateTab: (tab: string) => void;
  onOpenCreateOrder: () => void;
  onOpenAddProduct: () => void;
  onSelectOrderForPrint: (order: Order) => void;
  onStartTour: () => void;
  isDarkMode?: boolean;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  orders,
  products,
  currentUser,
  onNavigateTab,
  onOpenCreateOrder,
  onOpenAddProduct,
  onSelectOrderForPrint,
  onStartTour,
  isDarkMode = true,
}) => {
  const activeOrders = orders.filter((o) => o.status !== 'Cancelled' && o.status !== 'Delivered');
  const grossRevenuePKR = orders
    .filter((o) => o.status !== 'Cancelled')
    .reduce((sum, o) => sum + o.grandTotalPKR, 0);
  const collectedPKR = orders
    .filter((o) => o.status !== 'Cancelled')
    .reduce((sum, o) => sum + o.advancePaidPKR, 0);
  const pendingReceivablesPKR = orders
    .filter((o) => o.status !== 'Cancelled')
    .reduce((sum, o) => sum + o.balanceDuePKR, 0);

  const lowStockProducts = products.filter((p) => p.stockQty <= p.minStockAlert);

  // Status breakdown
  const statusCounts: Record<string, number> = {
    'Fabric Cut': 0,
    'In Tailoring': 0,
    'Fitting Scheduled': 0,
    'Ready for Dispatch': 0,
    'Delivered': 0,
  };

  orders.forEach((o) => {
    if (statusCounts[o.status] !== undefined) {
      statusCounts[o.status] += 1;
    }
  });

  return (
    <div className="space-y-6">
      {/* Welcome Banner & Quick Action Bar */}
      <div className={`flex flex-col md:flex-row md:items-center justify-between gap-4 p-6 rounded-2xl border shadow-xs transition-colors ${
        isDarkMode
          ? 'bg-gradient-to-r from-[#0C1220] via-[#0E1626] to-[#141F36] border-[#182338]'
          : 'bg-gradient-to-r from-[#FDFCFB] via-[#FAF9F6] to-[#F5EFE6] border-[#E7E2D8]'
      }`}>
        <div>
          <div className="flex items-center gap-2 text-xs text-[#D4AF37] font-semibold mb-1 tracking-wide">
            <span>Atelier Operational Center</span>
            <span aria-hidden="true">·</span>
            <span>Gulberg III, Lahore</span>
          </div>
          <h1 className={`text-xl md:text-2xl font-bold font-serif-display tracking-tight ${
            isDarkMode ? 'text-white' : 'text-stone-900'
          }`}>
            Atelier Executive Dashboard
          </h1>
          <p className={`text-xs mt-1 ${isDarkMode ? 'text-slate-400' : 'text-stone-600'}`}>
            Logged in as <strong className={isDarkMode ? 'text-slate-200' : 'text-stone-900'}>{currentUser.name}</strong> ({currentUser.role}). Real-time bespoke tailoring and financial ledger.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <button
            onClick={onOpenCreateOrder}
            className="flex items-center gap-2 px-4 py-2.5 text-xs font-bold text-slate-950 bg-[#D4AF37] hover:bg-[#E6CA85] rounded-xl transition-all shadow-xs"
          >
            <Plus className="w-4 h-4" />
            <span>New Suit Order</span>
          </button>

          <button
            onClick={onOpenAddProduct}
            className={`flex items-center gap-2 px-3.5 py-2.5 text-xs font-semibold rounded-xl border transition-colors ${
              isDarkMode
                ? 'text-slate-200 bg-[#121A2C] hover:bg-[#18233C] border-[#202E4A]'
                : 'text-stone-800 bg-white hover:bg-stone-50 border-stone-300'
            }`}
          >
            <Scissors className="w-4 h-4 text-[#D4AF37]" />
            <span>Add Fabric / Suit</span>
          </button>

          <button
            onClick={onStartTour}
            className={`flex items-center gap-2 px-3.5 py-2.5 text-xs font-medium rounded-xl border transition-colors ${
              isDarkMode
                ? 'text-[#E6CA85] bg-[#D4AF37]/10 hover:bg-[#D4AF37]/20 border-[#D4AF37]/30'
                : 'text-[#846227] bg-[#D4AF37]/15 hover:bg-[#D4AF37]/25 border-[#D4AF37]/40'
            }`}
          >
            <Sparkles className="w-4 h-4 text-[#D4AF37]" />
            <span>Client Tour</span>
          </button>
        </div>
      </div>

      {/* KPI Cards Strip */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Gross Revenue */}
        <div className={`p-5 rounded-2xl border transition-colors ${
          isDarkMode
            ? 'bg-[#0E1524] border-[#182338] hover:border-[#D4AF37]/35'
            : 'bg-white border-[#E7E2D8] hover:border-[#D4AF37]/50 shadow-xs'
        }`}>
          <div className={`flex items-center justify-between text-xs ${isDarkMode ? 'text-slate-400' : 'text-stone-500'}`}>
            <span>Gross Orders (PKR)</span>
            <TrendingUp className="w-4 h-4 text-emerald-400" />
          </div>
          <div className={`mt-3 text-2xl font-bold font-mono-numbers ${isDarkMode ? 'text-white' : 'text-stone-900'}`}>
            Rs. {grossRevenuePKR.toLocaleString()}
          </div>
          <div className={`mt-1 text-xs flex items-center gap-1.5 ${isDarkMode ? 'text-slate-400' : 'text-stone-500'}`}>
            <span className="text-emerald-500 font-semibold">PKR {collectedPKR.toLocaleString()}</span>
            <span>advance collected</span>
          </div>
        </div>

        {/* Pending Balance */}
        <div className={`p-5 rounded-2xl border transition-colors ${
          isDarkMode
            ? 'bg-[#0E1524] border-[#182338] hover:border-[#D4AF37]/35'
            : 'bg-white border-[#E7E2D8] hover:border-[#D4AF37]/50 shadow-xs'
        }`}>
          <div className={`flex items-center justify-between text-xs ${isDarkMode ? 'text-slate-400' : 'text-stone-500'}`}>
            <span>Pending Receivables</span>
            <ArrowUpRight className="w-4 h-4 text-[#D4AF37]" />
          </div>
          <div className={`mt-3 text-2xl font-bold font-mono-numbers ${isDarkMode ? 'text-[#E6CA85]' : 'text-[#846227]'}`}>
            Rs. {pendingReceivablesPKR.toLocaleString()}
          </div>
          <div className={`mt-1 text-xs ${isDarkMode ? 'text-slate-400' : 'text-stone-500'}`}>
            Pending COD / delivery settlement
          </div>
        </div>

        {/* Active Tailoring Pipeline */}
        <div className={`p-5 rounded-2xl border transition-colors ${
          isDarkMode
            ? 'bg-[#0E1524] border-[#182338] hover:border-[#D4AF37]/35'
            : 'bg-white border-[#E7E2D8] hover:border-[#D4AF37]/50 shadow-xs'
        }`}>
          <div className={`flex items-center justify-between text-xs ${isDarkMode ? 'text-slate-400' : 'text-stone-500'}`}>
            <span>Active Tailoring Orders</span>
            <Clock className="w-4 h-4 text-blue-400" />
          </div>
          <div className={`mt-3 text-2xl font-bold font-mono-numbers ${isDarkMode ? 'text-white' : 'text-stone-900'}`}>
            {activeOrders.length} Suits
          </div>
          <div className={`mt-1 text-xs ${isDarkMode ? 'text-slate-400' : 'text-stone-500'}`}>
            {statusCounts['Fitting Scheduled']} trials scheduled
          </div>
        </div>

        {/* Stock Alerts */}
        <div className={`p-5 rounded-2xl border transition-colors ${
          isDarkMode
            ? 'bg-[#0E1524] border-[#182338] hover:border-[#D4AF37]/35'
            : 'bg-white border-[#E7E2D8] hover:border-[#D4AF37]/50 shadow-xs'
        }`}>
          <div className={`flex items-center justify-between text-xs ${isDarkMode ? 'text-slate-400' : 'text-stone-500'}`}>
            <span>Fabric &amp; Stock Alerts</span>
            <AlertTriangle className={`w-4 h-4 ${lowStockProducts.length > 0 ? 'text-rose-400' : 'text-slate-400'}`} />
          </div>
          <div className={`mt-3 text-2xl font-bold font-mono-numbers ${isDarkMode ? 'text-white' : 'text-stone-900'}`}>
            {lowStockProducts.length} Items Low
          </div>
          <div className={`mt-1 text-xs ${isDarkMode ? 'text-slate-400' : 'text-stone-500'}`}>
            {products.length} bespoke designs active
          </div>
        </div>
      </div>

      {/* Production Pipeline Distribution */}
      <div className={`p-5 rounded-2xl border space-y-3 transition-colors ${
        isDarkMode ? 'bg-[#0E1524] border-[#182338]' : 'bg-white border-[#E7E2D8] shadow-xs'
      }`}>
        <div className="flex items-center justify-between">
          <div className={`text-xs font-bold uppercase tracking-wider ${isDarkMode ? 'text-slate-300' : 'text-stone-800'}`}>
            Bespoke Craftsmanship Stage Pipeline
          </div>
          <button
            onClick={() => onNavigateTab('orders')}
            className={`text-xs font-semibold hover:underline ${isDarkMode ? 'text-[#D4AF37]' : 'text-[#846227]'}`}
          >
            View all orders →
          </button>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
          {[
            { label: 'Fabric Cut', count: statusCounts['Fabric Cut'], darkClass: 'border-blue-500/30 bg-blue-500/10 text-blue-300', lightClass: 'border-blue-200 bg-blue-50 text-blue-800' },
            { label: 'In Tailoring', count: statusCounts['In Tailoring'], darkClass: 'border-[#D4AF37]/30 bg-[#D4AF37]/10 text-[#E6CA85]', lightClass: 'border-[#D4AF37]/40 bg-[#D4AF37]/10 text-[#846227]' },
            { label: 'Trial Fitting', count: statusCounts['Fitting Scheduled'], darkClass: 'border-purple-500/30 bg-purple-500/10 text-purple-300', lightClass: 'border-purple-200 bg-purple-50 text-purple-800' },
            { label: 'Ready for Dispatch', count: statusCounts['Ready for Dispatch'], darkClass: 'border-emerald-500/30 bg-emerald-500/10 text-emerald-300', lightClass: 'border-emerald-200 bg-emerald-50 text-emerald-800' },
            { label: 'Delivered', count: statusCounts['Delivered'], darkClass: 'border-slate-800 bg-[#121A2C] text-slate-300', lightClass: 'border-stone-200 bg-stone-100 text-stone-700' },
          ].map((stage) => (
            <div
              key={stage.label}
              className={`p-3.5 rounded-xl border flex flex-col justify-between ${isDarkMode ? stage.darkClass : stage.lightClass}`}
            >
              <div className="text-xs font-medium opacity-85">{stage.label}</div>
              <div className="text-xl font-bold font-mono-numbers mt-2">{stage.count}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Recent High-Priority Orders Table */}
      <div className={`rounded-2xl border overflow-hidden transition-colors ${
        isDarkMode ? 'bg-[#0E1524] border-[#182338]' : 'bg-white border-[#E7E2D8] shadow-xs'
      }`}>
        <div className={`flex items-center justify-between px-6 py-4 border-b ${
          isDarkMode ? 'border-[#182338] bg-[#090E18]' : 'border-[#E7E2D8] bg-[#FAF9F6]'
        }`}>
          <div>
            <h2 className={`text-sm font-bold font-serif-display ${isDarkMode ? 'text-white' : 'text-stone-900'}`}>
              Recent Bespoke Orders &amp; Delivery Queue
            </h2>
            <div className={`text-xs mt-0.5 ${isDarkMode ? 'text-slate-400' : 'text-stone-500'}`}>
              Live records from persistent store · Showing customer details per role permissions
            </div>
          </div>
          <button
            onClick={() => onNavigateTab('orders')}
            className={`text-xs font-semibold hover:underline ${isDarkMode ? 'text-[#D4AF37]' : 'text-[#846227]'}`}
          >
            Manage Pipeline
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className={`border-b font-medium ${
                isDarkMode ? 'border-[#182338] text-slate-400 bg-[#0B101B]' : 'border-[#E7E2D8] text-stone-500 bg-[#F5F2EB]'
              }`}>
                <th className="py-3.5 px-4">Order #</th>
                <th className="py-3.5 px-4">Client</th>
                <th className="py-3.5 px-4">Garment / Fabric</th>
                <th className="py-3.5 px-4">Delivery Due</th>
                <th className="py-3.5 px-4 text-right">Total (PKR)</th>
                <th className="py-3.5 px-4 text-center">Payment</th>
                <th className="py-3.5 px-4 text-center">Status</th>
                <th className="py-3.5 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className={`divide-y ${
              isDarkMode ? 'divide-[#182338] text-slate-200' : 'divide-[#E7E2D8] text-stone-800'
            }`}>
              {orders.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-10 text-center text-slate-400">
                    No orders booked yet. Click <span className="text-[#D4AF37] font-semibold">&quot;New Suit Order&quot;</span> above to create your first bespoke order.
                  </td>
                </tr>
              ) : (
                orders.slice(0, 5).map((ord) => {
                  const primaryItem = ord.items[0];
                  return (
                    <tr key={ord.id} className={`transition-colors ${
                      isDarkMode ? 'hover:bg-[#121A2C]' : 'hover:bg-[#FAF9F6]'
                    }`}>
                    <td className={`py-3.5 px-4 font-mono font-semibold ${
                      isDarkMode ? 'text-[#E6CA85]' : 'text-[#846227]'
                    }`}>
                      {ord.orderNumber}
                      {ord.isRushOrder && (
                        <span className="ml-2 text-[10px] text-rose-500 font-sans font-medium">
                          Rush
                        </span>
                      )}
                    </td>
                    <td className="py-3.5 px-4">
                      <div className={`font-semibold ${isDarkMode ? 'text-white' : 'text-stone-900'}`}>{ord.customerName}</div>
                      <div className="text-[11px] text-slate-400 font-mono">
                        {ord.customerCity} · {ord.customerPhone}
                      </div>
                    </td>
                    <td className="py-3.5 px-4 max-w-xs">
                      <div className={`font-medium truncate ${isDarkMode ? 'text-slate-200' : 'text-stone-800'}`}>
                        {primaryItem?.title || 'Bespoke Suit'}
                      </div>
                      <div className="text-[11px] text-slate-400 truncate">
                        {primaryItem?.fabric} · {primaryItem?.sizeOrTailoring}
                      </div>
                    </td>
                    <td className="py-3.5 px-4 font-mono text-slate-400">
                      <div className="flex items-center gap-1.5">
                        <Calendar className="w-3.5 h-3.5 text-slate-500" />
                        <span>{ord.deliveryDate}</span>
                      </div>
                    </td>
                    <td className={`py-3.5 px-4 text-right font-mono-numbers font-semibold ${
                      isDarkMode ? 'text-white' : 'text-stone-900'
                    }`}>
                      Rs. {ord.grandTotalPKR.toLocaleString()}
                      {ord.balanceDuePKR > 0 && (
                        <div className={`text-[10px] font-mono ${isDarkMode ? 'text-[#E6CA85]' : 'text-[#846227]'}`}>
                          Due: Rs. {ord.balanceDuePKR.toLocaleString()}
                        </div>
                      )}
                    </td>
                    <td className="py-3.5 px-4 text-center">
                      <span className={`text-[11px] font-semibold ${
                        ord.paymentStatus === 'Paid'
                          ? 'text-emerald-500'
                          : ord.paymentStatus === 'Partial'
                          ? isDarkMode ? 'text-[#E6CA85]' : 'text-[#846227]'
                          : 'text-rose-500'
                      }`}>
                        {ord.paymentStatus}
                      </span>
                    </td>
                    <td className="py-3.5 px-4 text-center">
                      <span className="text-[11px] font-medium text-slate-400">
                        {ord.status}
                      </span>
                    </td>
                    <td className="py-3.5 px-4 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          onClick={() => onSelectOrderForPrint(ord)}
                          className={`p-1.5 rounded-lg transition-colors ${
                            isDarkMode ? 'text-slate-400 hover:text-white hover:bg-[#182338]' : 'text-stone-500 hover:text-stone-900 hover:bg-stone-200'
                          }`}
                          title="Print Thermal POS Receipt (58mm/80mm)"
                        >
                          <Printer className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              }))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
